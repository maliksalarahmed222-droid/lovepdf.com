# LOVE PDF - Setup & Installation Guide

## Prerequisites

Before installing LOVE PDF, ensure you have:

- **Node.js** 18.x or higher
- **npm** 9.x or higher (or yarn/pnpm)
- **PostgreSQL** 14.x or higher
- **Redis** 6.x or higher (optional, for advanced features)
- **Git** for version control

## Local Development Setup

### Step 1: Clone the Repository

```bash
git clone https://github.com/yourusername/love-pdf.git
cd love-pdf
```

### Step 2: Install Dependencies

```bash
npm install
```

### Step 3: Configure Environment Variables

```bash
# Copy the example .env file
cp .env.example .env

# Edit .env with your configuration
nano .env
```

**Required Variables:**
```env
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/lovepdf
AUTH_SECRET=your-secret-key-min-32-characters
NODE_ENV=development
```

### Step 4: Set Up PostgreSQL Database

#### Option A: Manual Setup

```bash
# Create database
createdb lovepdf

# Run migrations
npx drizzle-kit push
```

#### Option B: Docker Setup

```bash
# Start PostgreSQL with Docker
docker run --name lovepdf-db \
  -e POSTGRES_DB=lovepdf \
  -e POSTGRES_PASSWORD=postgres \
  -p 5432:5432 \
  -d postgres:16-alpine
```

### Step 5: Start Development Server

```bash
npm run dev
```

The application will be available at `http://localhost:3000`

## Docker Development

### Using Docker Compose (Recommended)

```bash
# Start all services
docker-compose up

# Create database tables
docker-compose exec app npx drizzle-kit push
```

### Individual Docker Commands

```bash
# Build the image
docker build -t love-pdf:dev .

# Run the container
docker run -p 3000:3000 \
  -e DATABASE_URL=postgresql://postgres:postgres@host.docker.internal:5432/lovepdf \
  -e AUTH_SECRET=dev-secret \
  love-pdf:dev
```

## Database Setup

### Create Database Tables

```bash
# Push schema to database
npx drizzle-kit push

# Generate migration files
npx drizzle-kit generate

# Apply specific migration
npx drizzle-kit migrate
```

### Seed Database (Optional)

```bash
# Create seed file
npx drizzle-kit seed

# Run seeds
npm run db:seed
```

### View Database

```bash
# Connect to PostgreSQL
psql postgresql://postgres:postgres@localhost:5432/lovepdf

# List tables
\dt

# Exit
\q
```

## Development Commands

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Type checking
npm run typecheck

# Linting
npm run lint

# Run tests (when implemented)
npm test

# Database commands
npx drizzle-kit push      # Push schema changes
npx drizzle-kit generate  # Generate migrations
npx drizzle-kit migrate   # Run migrations
```

## Stripe Integration (Optional)

### Setup Stripe Account

1. Create account at https://stripe.com
2. Get API keys from Dashboard
3. Add to `.env`:

```env
STRIPE_SECRET_KEY=sk_live_...
STRIPE_PUBLISHABLE_KEY=pk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
```

### Local Webhook Testing

```bash
# Install Stripe CLI
brew install stripe/stripe-cli/stripe

# Login to Stripe
stripe login

# Forward webhooks to local server
stripe listen --forward-to localhost:3000/api/webhooks/stripe
```

## Google OAuth Setup (Optional)

### Create Google OAuth Credentials

1. Go to https://console.cloud.google.com
2. Create a new project
3. Enable Google+ API
4. Create OAuth 2.0 credentials (Web application)
5. Add authorized redirect URIs:
   - `http://localhost:3000/api/auth/callback/google`
   - `https://yourdomain.com/api/auth/callback/google`

6. Add to `.env`:

```env
GOOGLE_CLIENT_ID=your-client-id.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=your-client-secret
```

## Email Configuration (Optional)

### Using SendGrid

```bash
npm install @sendgrid/mail
```

Add to `.env`:
```env
SENDGRID_API_KEY=SG.your-api-key
EMAIL_FROM=noreply@lovepdf.com
```

### Using SMTP

Add to `.env`:
```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
EMAIL_FROM=noreply@lovepdf.com
```

## File Storage Setup (Optional)

### AWS S3

```bash
npm install aws-sdk
```

Add to `.env`:
```env
STORAGE_ENDPOINT=https://s3.amazonaws.com
STORAGE_ACCESS_KEY=your-access-key
STORAGE_SECRET_KEY=your-secret-key
STORAGE_BUCKET=lovepdf-files
STORAGE_REGION=us-east-1
```

### Minio (Self-Hosted S3-Compatible)

```bash
# Start Minio
docker run -p 9000:9000 -p 9001:9001 \
  -e MINIO_ROOT_USER=minioadmin \
  -e MINIO_ROOT_PASSWORD=minioadmin \
  minio/minio:latest server /data --console-address ":9001"
```

Add to `.env`:
```env
STORAGE_ENDPOINT=http://localhost:9000
STORAGE_ACCESS_KEY=minioadmin
STORAGE_SECRET_KEY=minioadmin
STORAGE_BUCKET=lovepdf
```

## Redis Setup (Optional)

### Local Redis

```bash
# Start Redis with Docker
docker run -d -p 6379:6379 redis:7-alpine

# Or install locally
brew install redis
redis-server
```

Add to `.env`:
```env
REDIS_URL=redis://localhost:6379
```

## Troubleshooting

### Database Connection Issues

```bash
# Test database connection
psql postgresql://postgres:postgres@localhost:5432/lovepdf -c "SELECT 1"

# Check if PostgreSQL is running
pg_isready -h localhost
```

### Port Already in Use

```bash
# Check what's using port 3000
lsof -i :3000

# Use different port
PORT=3001 npm run dev
```

### Module Not Found Errors

```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
npm run build
```

### Database Migration Issues

```bash
# Reset database (WARNING: Deletes all data)
dropdb lovepdf
createdb lovepdf
npx drizzle-kit push
```

## Performance Optimization

### Enable Source Maps (Production)

```bash
# Edit next.config.ts
productionBrowserSourceMaps: true
```

### Database Indexes

Indexes are already configured in schema.ts for frequently queried columns:
- `users.email`
- `files.user_id`
- `processing_jobs.user_id`
- `processing_jobs.status`

### Caching Strategy

Configure Redis for caching:

```env
REDIS_URL=redis://localhost:6379
```

## Security Checklist

- [ ] Change `AUTH_SECRET` to a strong random string
- [ ] Set `NODE_ENV=production` in production
- [ ] Use HTTPS in production
- [ ] Configure CORS properly
- [ ] Set up rate limiting
- [ ] Enable CSRF protection
- [ ] Regular database backups
- [ ] Monitor error logs
- [ ] Keep dependencies updated

## Monitoring & Logging

### Enable Request Logging

```env
LOG_LEVEL=info
```

### Error Tracking (Optional)

```bash
npm install @sentry/nextjs
```

Add to `.env`:
```env
SENTRY_DSN=https://your-sentry-dsn
```

### Database Monitoring

```bash
# View slow queries
psql postgresql://postgres:postgres@localhost:5432/lovepdf

# Enable query logging
ALTER SYSTEM SET log_statement = 'all';
SELECT pg_reload_conf();
```

## Regular Maintenance

### Weekly Tasks
- Check error logs
- Verify backups
- Monitor disk usage

### Monthly Tasks
- Update dependencies: `npm update`
- Review performance metrics
- Check for security vulnerabilities: `npm audit`

### Quarterly Tasks
- Full security audit
- Database optimization
- Performance review

## Next Steps

1. **Customize Branding**: Update `src/lib/constants.ts`
2. **Configure Payment**: Set up Stripe integration
3. **Deploy**: See `DEPLOYMENT.md`
4. **Monitor**: Set up error tracking and analytics
5. **Scale**: Configure caching and load balancing

## Support

- Documentation: https://docs.lovepdf.com
- Issues: https://github.com/yourusername/love-pdf/issues
- Email: support@lovepdf.com

## License

Proprietary - All rights reserved
