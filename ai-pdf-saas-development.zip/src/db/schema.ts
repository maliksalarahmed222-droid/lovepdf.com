import {
  pgTable,
  serial,
  text,
  varchar,
  timestamp,
  boolean,
  integer,
  decimal,
  jsonb,
  pgEnum,
  unique,
  index,
  primaryKey,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// Enums
export const userRoleEnum = pgEnum("user_role", ["FREE", "PRO", "BUSINESS"]);
export const subscriptionStatusEnum = pgEnum("subscription_status", [
  "ACTIVE",
  "INACTIVE",
  "CANCELLED",
  "PAST_DUE",
]);
export const jobStatusEnum = pgEnum("job_status", [
  "PENDING",
  "PROCESSING",
  "COMPLETED",
  "FAILED",
  "CANCELLED",
]);
export const toolTypeEnum = pgEnum("tool_type", [
  "MERGE",
  "SPLIT",
  "COMPRESS",
  "CONVERT",
  "EDIT",
  "SECURITY",
  "SIGN",
  "OCR",
  "WATERMARK",
  "AI",
]);

// ===== USERS & AUTH =====
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    email: varchar("email", { length: 255 }).notNull().unique(),
    name: varchar("name", { length: 255 }),
    passwordHash: text("password_hash"),
    emailVerified: boolean("email_verified").default(false),
    avatar: text("avatar"),
    role: userRoleEnum("role").default("FREE"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (table) => ({
    emailIdx: index("users_email_idx").on(table.email),
  })
);

export const usersRelations = relations(users, ({ one, many }) => ({
  subscription: one(subscriptions),
  files: many(files),
  apiKeys: many(apiKeys),
  team: one(teams),
  notifications: many(notifications),
  auditLogs: many(auditLogs),
}));

export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  token: varchar("token", { length: 255 }).notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const emailVerificationTokens = pgTable("email_verification_tokens", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull(),
  token: varchar("token", { length: 255 }).notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull(),
  token: varchar("token", { length: 255 }).notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// ===== SUBSCRIPTIONS & BILLING =====
export const subscriptions = pgTable(
  "subscriptions",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .unique()
      .references(() => users.id, { onDelete: "cascade" }),
    plan: userRoleEnum("plan").default("FREE"),
    status: subscriptionStatusEnum("status").default("INACTIVE"),
    stripeCustomerId: varchar("stripe_customer_id", { length: 255 }),
    stripeSubscriptionId: varchar("stripe_subscription_id", { length: 255 }),
    currentPeriodStart: timestamp("current_period_start"),
    currentPeriodEnd: timestamp("current_period_end"),
    cancelledAt: timestamp("cancelled_at"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (table) => ({
    userIdIdx: index("subscriptions_user_id_idx").on(table.userId),
  })
);

export const subscriptionsRelations = relations(subscriptions, ({ one, many }) => ({
  user: one(users, {
    fields: [subscriptions.userId],
    references: [users.id],
  }),
  payments: many(payments),
}));

export const payments = pgTable(
  "payments",
  {
    id: serial("id").primaryKey(),
    subscriptionId: integer("subscription_id")
      .notNull()
      .references(() => subscriptions.id, { onDelete: "cascade" }),
    stripePaymentIntentId: varchar("stripe_payment_intent_id", {
      length: 255,
    }).unique(),
    amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 3 }).default("USD"),
    status: varchar("status", { length: 50 }).default("pending"),
    invoiceUrl: text("invoice_url"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    subscriptionIdIdx: index("payments_subscription_id_idx").on(
      table.subscriptionId
    ),
  })
);

export const paymentsRelations = relations(payments, ({ one }) => ({
  subscription: one(subscriptions, {
    fields: [payments.subscriptionId],
    references: [subscriptions.id],
  }),
}));

// ===== FILES & STORAGE =====
export const files = pgTable(
  "files",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
    filename: varchar("filename", { length: 255 }).notNull(),
    mimeType: varchar("mime_type", { length: 50 }).notNull(),
    size: integer("size").notNull(),
    storagePath: varchar("storage_path", { length: 512 }).notNull(),
    storageKey: varchar("storage_key", { length: 512 }).notNull().unique(),
    isPublic: boolean("is_public").default(false),
    isFavorite: boolean("is_favorite").default(false),
    isDeleted: boolean("is_deleted").default(false),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
    expiresAt: timestamp("expires_at"),
  },
  (table) => ({
    userIdIdx: index("files_user_id_idx").on(table.userId),
    createdAtIdx: index("files_created_at_idx").on(table.createdAt),
  })
);

export const filesRelations = relations(files, ({ one, many }) => ({
  user: one(users, {
    fields: [files.userId],
    references: [users.id],
  }),
  jobs: many(processingJobs),
  shareLinks: many(shareLinks),
}));

export const shareLinks = pgTable(
  "share_links",
  {
    id: serial("id").primaryKey(),
    fileId: integer("file_id")
      .notNull()
      .references(() => files.id, { onDelete: "cascade" }),
    token: varchar("token", { length: 255 }).notNull().unique(),
    password: text("password"),
    allowDownload: boolean("allow_download").default(true),
    viewOnly: boolean("view_only").default(false),
    expiresAt: timestamp("expires_at"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    tokenIdx: index("share_links_token_idx").on(table.token),
  })
);

export const shareLinksRelations = relations(shareLinks, ({ one }) => ({
  file: one(files, {
    fields: [shareLinks.fileId],
    references: [files.id],
  }),
}));

// ===== PDF PROCESSING =====
export const processingJobs = pgTable(
  "processing_jobs",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
    fileId: integer("file_id").references(() => files.id, { onDelete: "cascade" }),
    toolType: toolTypeEnum("tool_type").notNull(),
    status: jobStatusEnum("status").default("PENDING"),
    inputFiles: jsonb("input_files"),
    parameters: jsonb("parameters"),
    resultFileId: integer("result_file_id").references(() => files.id),
    errorMessage: text("error_message"),
    processingTimeMs: integer("processing_time_ms"),
    createdAt: timestamp("created_at").defaultNow(),
    startedAt: timestamp("started_at"),
    completedAt: timestamp("completed_at"),
  },
  (table) => ({
    userIdIdx: index("processing_jobs_user_id_idx").on(table.userId),
    statusIdx: index("processing_jobs_status_idx").on(table.status),
  })
);

export const processingJobsRelations = relations(processingJobs, ({ one }) => ({
  user: one(users, {
    fields: [processingJobs.userId],
    references: [users.id],
  }),
  file: one(files, {
    fields: [processingJobs.fileId],
    references: [files.id],
  }),
  resultFile: one(files, {
    fields: [processingJobs.resultFileId],
    references: [files.id],
  }),
}));

export const toolUsage = pgTable(
  "tool_usage",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    toolType: toolTypeEnum("tool_type").notNull(),
    count: integer("count").default(1),
    date: timestamp("date").notNull(),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    userIdToolTypeIdx: index("tool_usage_user_id_tool_type_idx").on(
      table.userId,
      table.toolType
    ),
  })
);

// ===== AI FEATURES =====
export const aiConversations = pgTable(
  "ai_conversations",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    fileId: integer("file_id")
      .notNull()
      .references(() => files.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 255 }),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (table) => ({
    userIdIdx: index("ai_conversations_user_id_idx").on(table.userId),
  })
);

export const aiConversationsRelations = relations(
  aiConversations,
  ({ one, many }) => ({
    user: one(users, {
      fields: [aiConversations.userId],
      references: [users.id],
    }),
    file: one(files, {
      fields: [aiConversations.fileId],
      references: [files.id],
    }),
    messages: many(aiMessages),
  })
);

export const aiMessages = pgTable(
  "ai_messages",
  {
    id: serial("id").primaryKey(),
    conversationId: integer("conversation_id")
      .notNull()
      .references(() => aiConversations.id, { onDelete: "cascade" }),
    role: varchar("role", { length: 20 }).notNull(), // 'user' or 'assistant'
    content: text("content").notNull(),
    citations: jsonb("citations"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    conversationIdIdx: index("ai_messages_conversation_id_idx").on(
      table.conversationId
    ),
  })
);

export const aiMessagesRelations = relations(aiMessages, ({ one }) => ({
  conversation: one(aiConversations, {
    fields: [aiMessages.conversationId],
    references: [aiConversations.id],
  }),
}));

// ===== API PLATFORM =====
export const apiKeys = pgTable(
  "api_keys",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 255 }).notNull(),
    key: varchar("key", { length: 255 }).notNull().unique(),
    lastUsedAt: timestamp("last_used_at"),
    isActive: boolean("is_active").default(true),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    userIdIdx: index("api_keys_user_id_idx").on(table.userId),
    keyIdx: index("api_keys_key_idx").on(table.key),
  })
);

export const apiKeysRelations = relations(apiKeys, ({ one }) => ({
  user: one(users, {
    fields: [apiKeys.userId],
    references: [users.id],
  }),
}));

export const apiRequests = pgTable(
  "api_requests",
  {
    id: serial("id").primaryKey(),
    apiKeyId: integer("api_key_id")
      .notNull()
      .references(() => apiKeys.id, { onDelete: "cascade" }),
    endpoint: varchar("endpoint", { length: 255 }).notNull(),
    method: varchar("method", { length: 10 }).notNull(),
    statusCode: integer("status_code").notNull(),
    responseTimeMs: integer("response_time_ms"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    apiKeyIdIdx: index("api_requests_api_key_id_idx").on(table.apiKeyId),
  })
);

export const apiRequestsRelations = relations(apiRequests, ({ one }) => ({
  apiKey: one(apiKeys, {
    fields: [apiRequests.apiKeyId],
    references: [apiKeys.id],
  }),
}));

// ===== TEAMS & COLLABORATION =====
export const teams = pgTable(
  "teams",
  {
    id: serial("id").primaryKey(),
    ownerId: integer("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 255 }).notNull(),
    description: text("description"),
    logoUrl: text("logo_url"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (table) => ({
    ownerIdIdx: index("teams_owner_id_idx").on(table.ownerId),
  })
);

export const teamsRelations = relations(teams, ({ one, many }) => ({
  owner: one(users, {
    fields: [teams.ownerId],
    references: [users.id],
  }),
  members: many(teamMembers),
}));

export const teamMembers = pgTable(
  "team_members",
  {
    id: serial("id").primaryKey(),
    teamId: integer("team_id")
      .notNull()
      .references(() => teams.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    role: varchar("role", { length: 50 }).default("member"), // owner, admin, member
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    teamIdUserIdUnique: unique("team_members_team_id_user_id").on(
      table.teamId,
      table.userId
    ),
    teamIdIdx: index("team_members_team_id_idx").on(table.teamId),
    userIdIdx: index("team_members_user_id_idx").on(table.userId),
  })
);

export const teamMembersRelations = relations(teamMembers, ({ one }) => ({
  team: one(teams, {
    fields: [teamMembers.teamId],
    references: [teams.id],
  }),
  user: one(users, {
    fields: [teamMembers.userId],
    references: [users.id],
  }),
}));

// ===== CONTENT & HELP =====
export const blogPosts = pgTable(
  "blog_posts",
  {
    id: serial("id").primaryKey(),
    title: varchar("title", { length: 255 }).notNull(),
    slug: varchar("slug", { length: 255 }).notNull().unique(),
    content: text("content").notNull(),
    excerpt: text("excerpt"),
    authorId: integer("author_id").references(() => users.id),
    category: varchar("category", { length: 100 }),
    tags: jsonb("tags"),
    coverImageUrl: text("cover_image_url"),
    seoTitle: varchar("seo_title", { length: 255 }),
    seoDescription: text("seo_description"),
    isPublished: boolean("is_published").default(false),
    publishedAt: timestamp("published_at"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (table) => ({
    slugIdx: index("blog_posts_slug_idx").on(table.slug),
    publishedIdx: index("blog_posts_is_published_idx").on(table.isPublished),
  })
);

export const supportTickets = pgTable(
  "support_tickets",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    subject: varchar("subject", { length: 255 }).notNull(),
    message: text("message").notNull(),
    category: varchar("category", { length: 100 }),
    status: varchar("status", { length: 50 }).default("open"), // open, in-progress, resolved, closed
    priority: varchar("priority", { length: 50 }).default("normal"), // low, normal, high, urgent
    attachmentUrl: text("attachment_url"),
    adminNotes: text("admin_notes"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (table) => ({
    userIdIdx: index("support_tickets_user_id_idx").on(table.userId),
    statusIdx: index("support_tickets_status_idx").on(table.status),
  })
);

// ===== NOTIFICATIONS & AUDIT =====
export const notifications = pgTable(
  "notifications",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    type: varchar("type", { length: 100 }).notNull(),
    title: varchar("title", { length: 255 }).notNull(),
    message: text("message"),
    data: jsonb("data"),
    isRead: boolean("is_read").default(false),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    userIdIdx: index("notifications_user_id_idx").on(table.userId),
    isReadIdx: index("notifications_is_read_idx").on(table.isRead),
  })
);

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    action: varchar("action", { length: 255 }).notNull(),
    resourceType: varchar("resource_type", { length: 100 }),
    resourceId: varchar("resource_id", { length: 255 }),
    details: jsonb("details"),
    ipAddress: varchar("ip_address", { length: 45 }),
    userAgent: text("user_agent"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    userIdIdx: index("audit_logs_user_id_idx").on(table.userId),
    createdAtIdx: index("audit_logs_created_at_idx").on(table.createdAt),
  })
);

export const auditLogsRelations = relations(auditLogs, ({ one }) => ({
  user: one(users, {
    fields: [auditLogs.userId],
    references: [users.id],
  }),
}));

// ===== SYSTEM CONFIGURATION =====
export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 255 }).notNull().unique(),
  value: text("value").notNull(),
  type: varchar("type", { length: 50 }), // string, number, json, boolean
  description: text("description"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const featureFlags = pgTable(
  "feature_flags",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 255 }).notNull().unique(),
    description: text("description"),
    isEnabled: boolean("is_enabled").default(false),
    targetUsers: jsonb("target_users"), // null = all users, or array of user IDs
    rolloutPercentage: integer("rollout_percentage").default(0),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (table) => ({
    nameIdx: index("feature_flags_name_idx").on(table.name),
  })
);

// ===== USER USAGE TRACKING =====
export const userUsageStats = pgTable(
  "user_usage_stats",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .unique()
      .references(() => users.id, { onDelete: "cascade" }),
    tasksUsedToday: integer("tasks_used_today").default(0),
    tasksUsedThisMonth: integer("tasks_used_this_month").default(0),
    storageUsedBytes: integer("storage_used_bytes").default(0),
    aiRequestsUsed: integer("ai_requests_used").default(0),
    apiRequestsUsed: integer("api_requests_used").default(0),
    lastResetDate: timestamp("last_reset_date"),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (table) => ({
    userIdIdx: index("user_usage_stats_user_id_idx").on(table.userId),
  })
);

export const userUsageStatsRelations = relations(userUsageStats, ({ one }) => ({
  user: one(users, {
    fields: [userUsageStats.userId],
    references: [users.id],
  }),
}));
