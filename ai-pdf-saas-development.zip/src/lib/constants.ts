// Brand & Identity
export const BRAND_NAME = "LOVE PDF";
export const BRAND_TAGLINE = "Powerful PDF Tools. Simple by Design.";
export const BRAND_DESCRIPTION = "Merge, compress, convert, edit, sign and understand your PDFs with one fast, secure workspace.";

// Color Palette
export const COLORS = {
  background: "#F8FAFC",
  surface: "#FFFFFF",
  primary: "#172033",
  accent: "#D94B5B",
  secondary: "#64748B",
  border: "#E2E8F0",
  success: "#15803D",
  warning: "#B45309",
  error: "#B91C1C",
};

// Pricing Plans
export const PRICING_PLANS = {
  FREE: {
    name: "Free",
    price: 0,
    monthlyPrice: "$0",
    yearlyPrice: "$0",
    features: [
      "Basic PDF tools",
      "5 tasks/day",
      "25 MB maximum file size",
      "Basic compression",
      "Temporary processing",
      "Limited AI usage",
    ],
    limits: {
      tasksPerDay: 5,
      maxFileSize: 25 * 1024 * 1024, // 25 MB
      storageGB: 0,
      aiRequestsPerMonth: 5,
    },
  },
  PRO: {
    name: "Pro",
    price: 5.99,
    monthlyPrice: "$5.99",
    yearlyPrice: "$59",
    features: [
      "Higher usage limits",
      "250 MB files",
      "OCR",
      "PDF editor",
      "Signatures",
      "AI PDF",
      "Cloud storage (2GB)",
      "No ads",
      "Priority processing",
    ],
    limits: {
      tasksPerDay: 50,
      maxFileSize: 250 * 1024 * 1024, // 250 MB
      storageGB: 2,
      aiRequestsPerMonth: 100,
    },
  },
  BUSINESS: {
    name: "Business",
    price: 12.99,
    monthlyPrice: "$12.99",
    yearlyPrice: "$129",
    features: [
      "Everything in Pro",
      "Team workspace",
      "Shared documents",
      "Team management",
      "Audit logs",
      "API access",
      "1 GB files",
      "Higher limits (500 tasks/day)",
      "Priority support",
      "10 GB storage",
    ],
    limits: {
      tasksPerDay: 500,
      maxFileSize: 1024 * 1024 * 1024, // 1 GB
      storageGB: 10,
      aiRequestsPerMonth: 1000,
    },
  },
};

// PDF Tools Categories
export const TOOL_CATEGORIES = {
  ORGANIZE: {
    name: "Organize PDF",
    icon: "Layout",
    tools: [
      "merge-pdf",
      "split-pdf",
      "extract-pages",
      "delete-pages",
      "rearrange-pages",
      "rotate-pdf",
    ],
  },
  OPTIMIZE: {
    name: "Optimize PDF",
    icon: "Zap",
    tools: [
      "compress-pdf",
      "optimize-pdf",
      "repair-pdf",
      "flatten-pdf",
      "reduce-pdf-size",
    ],
  },
  CONVERT_TO: {
    name: "Convert to PDF",
    icon: "FileUp",
    tools: [
      "jpg-to-pdf",
      "png-to-pdf",
      "webp-to-pdf",
      "word-to-pdf",
      "excel-to-pdf",
      "html-to-pdf",
    ],
  },
  CONVERT_FROM: {
    name: "Convert from PDF",
    icon: "FileDown",
    tools: [
      "pdf-to-jpg",
      "pdf-to-png",
      "pdf-to-word",
      "pdf-to-excel",
      "pdf-to-text",
    ],
  },
  EDIT: {
    name: "Edit PDF",
    icon: "Edit",
    tools: [
      "edit-pdf",
      "add-text",
      "add-image",
      "highlight",
      "watermark-pdf",
      "redact-pdf",
    ],
  },
  SECURITY: {
    name: "PDF Security",
    icon: "Lock",
    tools: [
      "protect-pdf",
      "unlock-pdf",
      "encrypt-pdf",
      "remove-password",
      "remove-metadata",
    ],
  },
  SIGN: {
    name: "Sign PDF",
    icon: "PenTool",
    tools: ["sign-pdf", "request-signature"],
  },
  OCR: {
    name: "OCR",
    icon: "Eye",
    tools: ["ocr-pdf", "image-ocr", "make-searchable"],
  },
};

// Tool Metadata
export const TOOLS = {
  "merge-pdf": {
    name: "Merge PDF",
    description: "Combine multiple PDFs into one",
    category: "ORGANIZE",
    icon: "Merge2",
    requiresAuth: false,
    maxFiles: 20,
  },
  "split-pdf": {
    name: "Split PDF",
    description: "Extract pages or split PDF into multiple files",
    category: "ORGANIZE",
    icon: "Split",
    requiresAuth: false,
    maxFiles: 1,
  },
  "compress-pdf": {
    name: "Compress PDF",
    description: "Reduce PDF file size",
    category: "OPTIMIZE",
    icon: "Package",
    requiresAuth: false,
    maxFiles: 1,
  },
  "pdf-to-word": {
    name: "PDF to Word",
    description: "Convert PDF to DOCX format",
    category: "CONVERT_FROM",
    icon: "FileText",
    requiresAuth: false,
    maxFiles: 1,
  },
  "word-to-pdf": {
    name: "Word to PDF",
    description: "Convert DOCX to PDF",
    category: "CONVERT_TO",
    icon: "File",
    requiresAuth: false,
    maxFiles: 1,
  },
  "jpg-to-pdf": {
    name: "JPG to PDF",
    description: "Convert images to PDF",
    category: "CONVERT_TO",
    icon: "Image",
    requiresAuth: false,
    maxFiles: 20,
  },
  "pdf-to-jpg": {
    name: "PDF to JPG",
    description: "Convert PDF to images",
    category: "CONVERT_FROM",
    icon: "Image",
    requiresAuth: false,
    maxFiles: 1,
  },
  "edit-pdf": {
    name: "Edit PDF",
    description: "Add text, images, and more",
    category: "EDIT",
    icon: "Edit3",
    requiresAuth: false,
    maxFiles: 1,
  },
  "watermark-pdf": {
    name: "Watermark PDF",
    description: "Add text or image watermark",
    category: "EDIT",
    icon: "Type",
    requiresAuth: false,
    maxFiles: 1,
  },
  "sign-pdf": {
    name: "Sign PDF",
    description: "Add signatures to PDF",
    category: "SIGN",
    icon: "PenTool",
    requiresAuth: true,
    maxFiles: 1,
  },
  "protect-pdf": {
    name: "Protect PDF",
    description: "Encrypt PDF with password",
    category: "SECURITY",
    icon: "Lock",
    requiresAuth: false,
    maxFiles: 1,
  },
  "unlock-pdf": {
    name: "Unlock PDF",
    description: "Remove PDF password",
    category: "SECURITY",
    icon: "Unlock",
    requiresAuth: false,
    maxFiles: 1,
  },
  "ocr-pdf": {
    name: "OCR PDF",
    description: "Make PDF searchable with OCR",
    category: "OCR",
    icon: "Eye",
    requiresAuth: true,
    maxFiles: 1,
  },
  "ai-pdf": {
    name: "AI PDF",
    description: "Ask AI questions about your PDF",
    category: "AI",
    icon: "Sparkles",
    requiresAuth: true,
    maxFiles: 1,
  },
};

// File Upload Limits
export const UPLOAD_CONFIG = {
  maxFileSize: 1024 * 1024 * 1024, // 1 GB
  acceptedMimes: [
    "application/pdf",
    "image/jpeg",
    "image/png",
    "image/webp",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  ],
  acceptedExtensions: [
    "pdf",
    "jpg",
    "jpeg",
    "png",
    "webp",
    "docx",
    "xlsx",
    "pptx",
  ],
};

// Processing Timeouts
export const PROCESSING_TIMEOUTS = {
  merge: 60000,
  split: 30000,
  compress: 60000,
  convert: 120000,
  ocr: 180000,
  edit: 30000,
  watermark: 30000,
  sign: 30000,
};

// File Retention
export const FILE_RETENTION = {
  tempFileRetentionHours: 24,
  deletedFileRetentionDays: 30,
};

// API Rate Limits
export const RATE_LIMITS = {
  free: {
    requestsPerHour: 10,
    requestsPerDay: 50,
  },
  pro: {
    requestsPerHour: 100,
    requestsPerDay: 1000,
  },
  business: {
    requestsPerHour: 1000,
    requestsPerDay: 10000,
  },
};

// Session Configuration
export const SESSION_CONFIG = {
  maxAge: 7 * 24 * 60 * 60, // 7 days
  refreshThreshold: 24 * 60 * 60, // 1 day
};

// Email Configuration
export const EMAIL_TEMPLATES = {
  WELCOME: "welcome",
  EMAIL_VERIFICATION: "email_verification",
  PASSWORD_RESET: "password_reset",
  SUBSCRIPTION_CONFIRMATION: "subscription_confirmation",
  PROCESSING_COMPLETE: "processing_complete",
};

// Feature Flags
export const FEATURES = {
  AI_PDF: true,
  API_PLATFORM: true,
  TEAM_WORKSPACE: true,
  CUSTOM_BRANDING: false,
  WEBHOOKS: false,
};
