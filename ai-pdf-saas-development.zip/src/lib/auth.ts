import { cookies } from "next/headers";
import { jwtVerify, SignJWT } from "jose";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import crypto from "crypto";

const SECRET = new TextEncoder().encode(
  process.env.AUTH_SECRET || "dev-secret-key-change-in-production"
);

export interface SessionData {
  userId: number;
  email: string;
  iat: number;
  exp: number;
}

export async function createSession(userId: number, email: string) {
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days

  const payload = {
    userId,
    email,
  };

  const token = await new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(SECRET);

  // Store in database
  await db.insert(sessions).values({
    userId,
    token,
    expiresAt,
  });

  // Set cookie
  const cookieStore = await cookies();
  cookieStore.set("session", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60,
    path: "/",
  });

  return token;
}

export async function verifySession(): Promise<SessionData | null> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("session")?.value;

    if (!token) return null;

    // Verify JWT
    const verified = await jwtVerify(token, SECRET);
    const sessionData = verified.payload as unknown as SessionData;

    // Check if session exists and is valid
    const sessionList = await db
      .select()
      .from(sessions)
      .where(eq(sessions.token, token))
      .limit(1);

    if (!sessionList.length || sessionList[0].expiresAt < new Date()) {
      return null;
    }

    return sessionData;
  } catch (err) {
    return null;
  }
}

export async function clearSession() {
  const cookieStore = await cookies();
  cookieStore.delete("session");
}

export async function getUserFromSession() {
  const sessionData = await verifySession();
  if (!sessionData) return null;

  const userList = await db
    .select()
    .from(users)
    .where(eq(users.id, sessionData.userId))
    .limit(1);

  return userList.length ? userList[0] : null;
}

export function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password).digest("hex");
}

export function verifyPassword(password: string, hash: string): boolean {
  return crypto.createHash("sha256").update(password).digest("hex") === hash;
}
