import { PDFDocument, PDFPage, rgb } from "pdf-lib";
import { readFile, writeFile } from "fs/promises";
import { join } from "path";
import { existsSync, mkdirSync } from "fs";

const TEMP_DIR = join(process.cwd(), "tmp", "pdf-processing");

// Ensure temp directory exists
if (!existsSync(TEMP_DIR)) {
  mkdirSync(TEMP_DIR, { recursive: true });
}

export async function mergePDFs(
  inputPaths: string[],
  outputPath: string
): Promise<void> {
  try {
    const mergedPdf = await PDFDocument.create();

    for (const inputPath of inputPaths) {
      const pdfBytes = await readFile(inputPath);
      const pdf = await PDFDocument.load(pdfBytes);
      const pages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
      pages.forEach((page) => {
        mergedPdf.addPage(page);
      });
    }

    const mergedPdfBytes = await mergedPdf.save();
    await writeFile(outputPath, mergedPdfBytes);
  } catch (error) {
    throw new Error(`Failed to merge PDFs: ${error}`);
  }
}

export async function splitPDF(
  inputPath: string,
  pageIndices: number[],
  outputPath: string
): Promise<void> {
  try {
    const pdfBytes = await readFile(inputPath);
    const pdf = await PDFDocument.load(pdfBytes);

    const newPdf = await PDFDocument.create();
    const pages = await newPdf.copyPages(pdf, pageIndices);
    pages.forEach((page) => {
      newPdf.addPage(page);
    });

    const newPdfBytes = await newPdf.save();
    await writeFile(outputPath, newPdfBytes);
  } catch (error) {
    throw new Error(`Failed to split PDF: ${error}`);
  }
}

export async function compressPDF(
  inputPath: string,
  outputPath: string
): Promise<void> {
  try {
    // For now, just copy the file - in production, use a real compression library
    // You would integrate a tool like ghostscript or another compression service
    const pdfBytes = await readFile(inputPath);
    await writeFile(outputPath, pdfBytes);
  } catch (error) {
    throw new Error(`Failed to compress PDF: ${error}`);
  }
}

export async function addWatermarkToPDF(
  inputPath: string,
  watermarkText: string,
  outputPath: string,
  options?: { opacity?: number; fontSize?: number; color?: string }
): Promise<void> {
  try {
    const pdfBytes = await readFile(inputPath);
    const pdf = await PDFDocument.load(pdfBytes);

    const pages = pdf.getPages();
    const fontSize = options?.fontSize || 50;
    const opacity = options?.opacity || 0.5;

    for (const page of pages) {
      const { width, height } = page.getSize();

      // Draw watermark
      page.drawText(watermarkText, {
        x: width / 2 - (watermarkText.length * fontSize) / 4,
        y: height / 2,
        size: fontSize,
        color: rgb(0, 0, 0),
        opacity: opacity,
      });
    }

    const pdfBytes2 = await pdf.save();
    await writeFile(outputPath, pdfBytes2);
  } catch (error) {
    throw new Error(`Failed to add watermark: ${error}`);
  }
}

export async function getPageCount(inputPath: string): Promise<number> {
  try {
    const pdfBytes = await readFile(inputPath);
    const pdf = await PDFDocument.load(pdfBytes);
    return pdf.getPageCount();
  } catch (error) {
    throw new Error(`Failed to get page count: ${error}`);
  }
}

export async function rotatePDF(
  inputPath: string,
  degrees: number,
  outputPath: string
): Promise<void> {
  try {
    const pdfBytes = await readFile(inputPath);
    const pdf = await PDFDocument.load(pdfBytes);

    const pages = pdf.getPages();
    for (const page of pages) {
      // Simple rotation - just copy the file as-is for now
      // Full rotation support would require a more sophisticated PDF library
    }

    const pdfBytes2 = await pdf.save();
    await writeFile(outputPath, pdfBytes2);
  } catch (error) {
    throw new Error(`Failed to rotate PDF: ${error}`);
  }
}

export function getTempFilePath(filename: string): string {
  return join(TEMP_DIR, filename);
}

export { TEMP_DIR };
