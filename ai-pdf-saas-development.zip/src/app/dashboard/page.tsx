"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  Sparkles,
  LogOut,
  FileUp,
  Merge,
  Package,
  Eye,
  Lock,
  PenTool,
} from "lucide-react";

interface User {
  id: number;
  email: string;
  name: string;
  role: string;
}

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check if user is authenticated
    const checkAuth = async () => {
      try {
        const response = await fetch("/api/auth/me");
        if (!response.ok) {
          router.push("/login");
          return;
        }

        const data = await response.json();
        setUser(data.user);
      } catch (err) {
        router.push("/login");
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, [router]);

  async function handleLogout() {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      router.push("/");
    } catch (err) {
      console.error("Logout error:", err);
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-red-100">
            <Sparkles className="h-6 w-6 animate-spin text-red-600" />
          </div>
          <p className="mt-4 text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navigation */}
      <nav className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded bg-red-600">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="font-bold text-slate-900">LOVE PDF</span>
            </Link>

            <div className="flex items-center gap-4">
              <span className="text-sm text-slate-600">{user.email}</span>
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 rounded-lg bg-slate-100 px-4 py-2 text-sm font-medium text-slate-900 hover:bg-slate-200"
              >
                <LogOut className="h-4 w-4" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Dashboard Content */}
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="mb-12">
          <h1 className="text-3xl font-bold text-slate-900">
            Welcome back, {user.name}!
          </h1>
          <p className="mt-2 text-slate-600">
            You're on the <span className="font-semibold">{user.role}</span>{" "}
            plan
          </p>
        </div>

        {/* Quick Actions */}
        <div className="mb-12">
          <h2 className="mb-6 text-xl font-bold text-slate-900">
            Quick Actions
          </h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: Merge,
                label: "Merge PDF",
                href: "/merge-pdf",
              },
              {
                icon: Package,
                label: "Compress PDF",
                href: "/compress-pdf",
              },
              {
                icon: FileUp,
                label: "Convert PDF",
                href: "/pdf-to-word",
              },
              {
                icon: Eye,
                label: "OCR PDF",
                href: "/ocr-pdf",
              },
              {
                icon: Lock,
                label: "Protect PDF",
                href: "/protect-pdf",
              },
              {
                icon: PenTool,
                label: "Sign PDF",
                href: "/sign-pdf",
              },
            ].map((action) => {
              const Icon = action.icon;
              return (
                <Link
                  key={action.href}
                  href={action.href}
                  className="flex items-center gap-4 rounded-lg border border-slate-200 bg-white p-6 transition hover:shadow-lg"
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-red-100">
                    <Icon className="h-6 w-6 text-red-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900">
                      {action.label}
                    </h3>
                    <p className="text-sm text-slate-600">
                      Get started now →
                    </p>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>

        {/* My Files */}
        <div>
          <h2 className="mb-6 text-xl font-bold text-slate-900">My Files</h2>
          <div className="rounded-lg border border-slate-200 bg-white p-8 text-center">
            <FileUp className="mx-auto h-12 w-12 text-slate-400" />
            <p className="mt-4 text-slate-600">No files yet</p>
            <p className="text-sm text-slate-500">
              Upload your first PDF to get started
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
