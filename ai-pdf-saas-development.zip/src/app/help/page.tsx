import { Metadata } from "next";
import Link from "next/link";
import { Sparkles, Search, MessageSquare, Book, ArrowRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Help Center - LOVE PDF",
  description: "Get help with LOVE PDF tools and services",
};

export default function HelpPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navbar */}
      <nav className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded bg-red-600">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="font-bold text-slate-900">LOVE PDF</span>
            </Link>

            <Link
              href="/signup"
              className="rounded bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700"
            >
              Get Started
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="border-b border-slate-200 bg-white py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold text-slate-900">Help Center</h1>
          <p className="mt-2 text-slate-600">Find answers and solutions</p>

          <div className="mt-8 flex">
            <input
              type="text"
              placeholder="Search for help..."
              className="flex-1 rounded-l-lg border border-slate-300 px-4 py-2"
            />
            <button className="rounded-r-lg bg-red-600 px-6 py-2 text-white hover:bg-red-700">
              <Search className="h-5 w-5" />
            </button>
          </div>
        </div>
      </section>

      {/* Help Categories */}
      <section className="py-12">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: Book,
                title: "Getting Started",
                description: "Learn the basics of LOVE PDF",
                links: [
                  "What is LOVE PDF?",
                  "Creating an account",
                  "First steps",
                ],
              },
              {
                icon: MessageSquare,
                title: "Account & Billing",
                description: "Manage your account and subscription",
                links: [
                  "Subscription plans",
                  "Billing and payments",
                  "Cancelling subscription",
                ],
              },
              {
                icon: Search,
                title: "PDF Tools",
                description: "How to use each PDF tool",
                links: [
                  "Merge PDFs",
                  "Compress PDFs",
                  "Convert PDFs",
                ],
              },
              {
                icon: MessageSquare,
                title: "AI PDF",
                description: "Using AI features",
                links: [
                  "How to use AI PDF",
                  "Privacy and AI",
                  "AI limitations",
                ],
              },
              {
                icon: MessageSquare,
                title: "Security",
                description: "File safety and privacy",
                links: [
                  "How we protect files",
                  "Encryption explained",
                  "Privacy policy",
                ],
              },
              {
                icon: MessageSquare,
                title: "Troubleshooting",
                description: "Common issues and solutions",
                links: [
                  "Upload issues",
                  "Processing errors",
                  "Download problems",
                ],
              },
            ].map((category) => {
              const Icon = category.icon;
              return (
                <div
                  key={category.title}
                  className="rounded-lg border border-slate-200 bg-white p-6"
                >
                  <Icon className="h-8 w-8 text-red-600" />
                  <h3 className="mt-4 font-semibold text-slate-900">
                    {category.title}
                  </h3>
                  <p className="mt-2 text-sm text-slate-600">
                    {category.description}
                  </p>
                  <ul className="mt-4 space-y-2">
                    {category.links.map((link) => (
                      <li key={link}>
                        <a
                          href="#"
                          className="text-sm text-red-600 hover:text-red-700"
                        >
                          {link}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="border-y border-slate-200 bg-slate-50 py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-slate-900">
            Frequently Asked Questions
          </h2>

          <div className="mt-8 space-y-4">
            {[
              {
                q: "How large can my files be?",
                a: "Free plan supports up to 25MB. Pro plan supports 250MB. Business plan supports 1GB.",
              },
              {
                q: "How long does processing take?",
                a: "Most operations complete in seconds. Large files may take longer.",
              },
              {
                q: "Are my files secure?",
                a: "Yes, files are encrypted during transfer and automatically deleted after 24 hours.",
              },
              {
                q: "Do I need an account?",
                a: "No, you can use basic tools without an account. Create an account to save files.",
              },
            ].map((item, idx) => (
              <details
                key={idx}
                className="rounded-lg border border-slate-200 bg-white p-4"
              >
                <summary className="cursor-pointer font-medium text-slate-900">
                  {item.q}
                </summary>
                <p className="mt-4 text-slate-600">{item.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Support */}
      <section className="py-12">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-slate-900">
            Can't find what you need?
          </h2>
          <p className="mt-2 text-slate-600">
            Contact our support team for help
          </p>
          <Link
            href="/contact"
            className="mt-6 inline-flex items-center gap-2 rounded-lg bg-red-600 px-8 py-3 font-medium text-white hover:bg-red-700"
          >
            Contact Support
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-12">
        <div className="mx-auto max-w-6xl px-4 text-center sm:px-6 lg:px-8">
          <p className="text-slate-600">© 2024 LOVE PDF. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
