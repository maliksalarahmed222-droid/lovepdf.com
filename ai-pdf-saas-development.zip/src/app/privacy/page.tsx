import { Metadata } from "next";
import Link from "next/link";
import { Sparkles } from "lucide-react";

export const metadata: Metadata = {
  title: "Privacy Policy - LOVE PDF",
  description: "Privacy policy for LOVE PDF",
};

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navbar */}
      <nav className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded bg-red-600">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="font-bold text-slate-900">LOVE PDF</span>
            </Link>
          </div>
        </div>
      </nav>

      {/* Content */}
      <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-slate-900">Privacy Policy</h1>
        <p className="mt-2 text-slate-600">Last updated: January 2024</p>

        <div className="prose prose-slate mt-8 max-w-none">
          <h2>1. Introduction</h2>
          <p>
            LOVE PDF ("we," "us," "our," or "Company") is committed to protecting
            your privacy. This Privacy Policy explains how we collect, use, disclose,
            and safeguard your information when you visit our website and use our
            services.
          </p>

          <h2>2. Information We Collect</h2>
          <p>We may collect information about you in a variety of ways.</p>

          <h3>2.1 Information You Voluntarily Provide</h3>
          <ul>
            <li>Account registration information (name, email, password)</li>
            <li>Profile information</li>
            <li>Payment information (processed securely through Stripe)</li>
            <li>Communications with our support team</li>
          </ul>

          <h3>2.2 Information Automatically Collected</h3>
          <ul>
            <li>Log data (IP address, browser type, pages visited)</li>
            <li>Device information</li>
            <li>Cookies and similar tracking technologies</li>
            <li>Usage patterns and analytics</li>
          </ul>

          <h2>3. How We Use Your Information</h2>
          <p>We use the information we collect to:</p>
          <ul>
            <li>Provide, maintain, and improve our services</li>
            <li>Process transactions and send related information</li>
            <li>Send promotional communications (with your consent)</li>
            <li>Respond to inquiries and provide customer support</li>
            <li>Monitor and analyze trends and usage</li>
            <li>Prevent fraudulent transactions and enhance security</li>
            <li>Comply with legal obligations</li>
          </ul>

          <h2>4. File Storage and Deletion</h2>
          <p>
            PDF files you upload are processed securely and automatically deleted
            within 24 hours. We do not store your files permanently unless you
            explicitly save them to your account.
          </p>

          <h2>5. AI and Data Processing</h2>
          <p>
            When you use AI PDF features, your document is processed by our AI
            providers. We do not use your documents to train AI models. Your
            documents are deleted immediately after processing.
          </p>

          <h2>6. Sharing of Information</h2>
          <p>We do not sell, trade, or rent your personal information. We may share information:</p>
          <ul>
            <li>With service providers who assist us in operating our website</li>
            <li>When required by law or legal process</li>
            <li>To protect our rights and your safety</li>
          </ul>

          <h2>7. Security</h2>
          <p>
            We implement appropriate technical and organizational measures to
            protect your information against unauthorized access, alteration,
            disclosure, or destruction.
          </p>

          <h2>8. Cookies</h2>
          <p>
            We use cookies to enhance your experience. You can control cookie
            settings through your browser preferences.
          </p>

          <h2>9. Your Rights</h2>
          <p>You have the right to:</p>
          <ul>
            <li>Access your personal information</li>
            <li>Correct inaccurate information</li>
            <li>Request deletion of your information</li>
            <li>Opt-out of marketing communications</li>
            <li>Data portability</li>
          </ul>

          <h2>10. Changes to This Policy</h2>
          <p>
            We may update this Privacy Policy from time to time. We will notify
            you of any changes by posting the new policy on this page.
          </p>

          <h2>11. Contact Us</h2>
          <p>
            If you have questions about this Privacy Policy, please contact us at:
            privacy@lovepdf.com
          </p>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-12">
        <div className="mx-auto max-w-6xl px-4 text-center sm:px-6 lg:px-8">
          <p className="text-slate-600">© 2024 LOVE PDF. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
