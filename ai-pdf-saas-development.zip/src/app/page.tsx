import { Metadata } from "next";
import Link from "next/link";
import {
  Sparkles,
  Lock,
  Zap,
  FileUp,
  ArrowRight,
  Check,
  Star,
} from "lucide-react";
import { BRAND_NAME, BRAND_TAGLINE, TOOL_CATEGORIES } from "@/lib/constants";

export const metadata: Metadata = {
  title: "LOVE PDF - Powerful PDF Tools. Simple by Design.",
  description:
    "Merge, compress, convert, edit, sign and understand your PDFs with one fast, secure workspace.",
};

export default function HomePage() {
  return (
    <>
      {/* Navigation */}
      <nav className="sticky top-0 z-40 border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded bg-red-600">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="font-bold text-slate-900">{BRAND_NAME}</span>
            </Link>

            <div className="hidden items-center gap-8 md:flex">
              <a
                href="/tools"
                className="text-sm text-slate-600 hover:text-slate-900"
              >
                Tools
              </a>
              <a
                href="/ai-pdf"
                className="text-sm text-slate-600 hover:text-slate-900"
              >
                AI PDF
              </a>
              <a
                href="/pricing"
                className="text-sm text-slate-600 hover:text-slate-900"
              >
                Pricing
              </a>
              <a
                href="/help"
                className="text-sm text-slate-600 hover:text-slate-900"
              >
                Help
              </a>
            </div>

            <div className="flex items-center gap-4">
              <Link
                href="/login"
                className="hidden text-sm text-slate-600 hover:text-slate-900 md:block"
              >
                Login
              </Link>
              <Link
                href="/signup"
                className="rounded bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700"
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="border-b border-slate-200 bg-white py-20">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <h1 className="text-5xl font-bold tracking-tight text-slate-900 sm:text-6xl">
            {BRAND_TAGLINE}
          </h1>
          <p className="mt-6 text-xl text-slate-600">
            Merge, compress, convert, edit, sign and understand your PDFs with
            one fast, secure workspace.
          </p>

          <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:justify-center">
            <Link
              href="/tools"
              className="inline-flex items-center justify-center gap-2 rounded bg-red-600 px-8 py-3 font-medium text-white hover:bg-red-700"
            >
              Explore PDF Tools
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              href="/signup"
              className="inline-flex items-center justify-center rounded border border-slate-300 px-8 py-3 font-medium text-slate-900 hover:bg-slate-50"
            >
              Get Started Free
            </Link>
          </div>

          {/* Upload Demo */}
          <div className="mt-12 rounded-lg border-2 border-dashed border-slate-300 bg-slate-50 p-12">
            <div className="flex flex-col items-center gap-4">
              <FileUp className="h-12 w-12 text-slate-400" />
              <div>
                <p className="font-medium text-slate-900">
                  Drop your PDF here
                </p>
                <p className="text-sm text-slate-600">
                  or click to browse from your device
                </p>
              </div>
            </div>
          </div>

          <div className="mt-8 flex flex-wrap justify-center gap-4 text-sm text-slate-600">
            <span>PDF</span>
            <span>•</span>
            <span>JPG, PNG</span>
            <span>•</span>
            <span>Up to 1 GB</span>
          </div>
        </div>
      </section>

      {/* Popular Tools */}
      <section className="border-b border-slate-200 bg-slate-50 py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-3xl font-bold text-slate-900">
            Popular PDF Tools
          </h2>
          <p className="mt-4 text-center text-slate-600">
            Choose from 56 powerful PDF tools
          </p>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                name: "Merge PDF",
                description: "Combine multiple PDFs into one",
                href: "/merge-pdf",
              },
              {
                name: "Compress PDF",
                description: "Reduce PDF file size",
                href: "/compress-pdf",
              },
              {
                name: "Split PDF",
                description: "Extract pages or split files",
                href: "/split-pdf",
              },
              {
                name: "PDF to Word",
                description: "Convert PDF to DOCX format",
                href: "/pdf-to-word",
              },
              {
                name: "JPG to PDF",
                description: "Convert images to PDF",
                href: "/jpg-to-pdf",
              },
              {
                name: "Edit PDF",
                description: "Add text, images, and more",
                href: "/edit-pdf",
              },
            ].map((tool) => (
              <Link
                key={tool.href}
                href={tool.href}
                className="rounded-lg border border-slate-200 bg-white p-6 transition hover:shadow-lg"
              >
                <h3 className="font-semibold text-slate-900">{tool.name}</h3>
                <p className="mt-2 text-sm text-slate-600">
                  {tool.description}
                </p>
                <div className="mt-4 flex items-center text-red-600">
                  <span className="text-sm font-medium">Get Started</span>
                  <ArrowRight className="ml-2 h-4 w-4" />
                </div>
              </Link>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Link
              href="/tools"
              className="inline-flex items-center gap-2 text-red-600 hover:text-red-700"
            >
              View all 56 tools
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Tool Categories */}
      <section className="border-b border-slate-200 bg-white py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-3xl font-bold text-slate-900">
            Organized by Category
          </h2>

          <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { name: "Organize PDF", count: 9 },
              { name: "Optimize PDF", count: 5 },
              { name: "Convert to PDF", count: 9 },
              { name: "Convert from PDF", count: 9 },
              { name: "Edit PDF", count: 10 },
              { name: "PDF Security", count: 5 },
              { name: "Sign PDF", count: 2 },
              { name: "OCR & AI", count: 6 },
            ].map((category) => (
              <div
                key={category.name}
                className="rounded-lg border border-slate-200 p-6 text-center"
              >
                <h3 className="font-semibold text-slate-900">
                  {category.name}
                </h3>
                <p className="mt-2 text-2xl font-bold text-red-600">
                  {category.count}
                </p>
                <p className="text-sm text-slate-600">tools</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Love PDF */}
      <section className="border-b border-slate-200 bg-slate-50 py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-3xl font-bold text-slate-900">
            Why LOVE PDF?
          </h2>

          <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: Zap,
                title: "Fast",
                description: "Process PDFs in seconds, not minutes",
              },
              {
                icon: Lock,
                title: "Secure",
                description:
                  "Your documents are encrypted and automatically deleted",
              },
              {
                icon: Check,
                title: "Simple",
                description: "Upload, choose tool, download - that's it",
              },
              {
                icon: Star,
                title: "Free to Start",
                description: "Access core tools without payment",
              },
              {
                icon: Sparkles,
                title: "Powerful",
                description: "56 tools for every PDF need",
              },
              {
                icon: ArrowRight,
                title: "Professional",
                description: "Used by students, lawyers, and enterprises",
              },
            ].map((feature) => {
              const Icon = feature.icon;
              return (
                <div key={feature.title} className="rounded-lg bg-white p-8">
                  <Icon className="h-8 w-8 text-red-600" />
                  <h3 className="mt-4 font-semibold text-slate-900">
                    {feature.title}
                  </h3>
                  <p className="mt-2 text-slate-600">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="border-b border-slate-200 bg-white py-16">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-3xl font-bold text-slate-900">
            How It Works
          </h2>

          <div className="mt-12 grid gap-8 sm:grid-cols-4">
            {[
              { step: "1", title: "Upload", description: "Select your PDF" },
              {
                step: "2",
                title: "Choose",
                description: "Pick a tool",
              },
              {
                step: "3",
                title: "Process",
                description: "We handle it",
              },
              {
                step: "4",
                title: "Download",
                description: "Get your file",
              },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-red-600 text-white font-bold">
                  {item.step}
                </div>
                <h3 className="mt-4 font-semibold text-slate-900">
                  {item.title}
                </h3>
                <p className="mt-2 text-sm text-slate-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AI PDF CTA */}
      <section className="border-b border-slate-200 bg-slate-50 py-16">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <div className="inline-flex items-center gap-2 rounded-full bg-red-100 px-4 py-2">
            <Sparkles className="h-4 w-4 text-red-600" />
            <span className="text-sm font-medium text-red-600">
              AI Powered
            </span>
          </div>
          <h2 className="mt-6 text-3xl font-bold text-slate-900">
            Your PDF Can Answer Questions
          </h2>
          <p className="mt-4 text-lg text-slate-600">
            Use AI to extract information, summarize documents, and find
            specific content instantly.
          </p>
          <Link
            href="/ai-pdf"
            className="mt-8 inline-flex items-center gap-2 rounded bg-red-600 px-8 py-3 font-medium text-white hover:bg-red-700"
          >
            Try AI PDF
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* Pricing Preview */}
      <section className="border-b border-slate-200 bg-white py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-3xl font-bold text-slate-900">
            Simple, Transparent Pricing
          </h2>

          <div className="mt-12 grid gap-8 sm:grid-cols-3">
            {[
              {
                name: "Free",
                price: "$0",
                features: [
                  "5 tasks/day",
                  "25 MB files",
                  "Basic tools",
                  "No ads",
                ],
              },
              {
                name: "Pro",
                price: "$5.99",
                period: "/month",
                highlighted: true,
                features: [
                  "250 MB files",
                  "OCR & Editor",
                  "AI PDF",
                  "Priority processing",
                ],
              },
              {
                name: "Business",
                price: "$12.99",
                period: "/user/month",
                features: [
                  "1 GB files",
                  "Team workspace",
                  "API access",
                  "Audit logs",
                ],
              },
            ].map((plan) => (
              <div
                key={plan.name}
                className={`rounded-lg p-8 ${
                  plan.highlighted
                    ? "border-2 border-red-600 bg-red-50"
                    : "border border-slate-200 bg-white"
                }`}
              >
                <h3 className="text-2xl font-bold text-slate-900">
                  {plan.name}
                </h3>
                <div className="mt-4 flex items-baseline gap-1">
                  <span className="text-4xl font-bold text-slate-900">
                    {plan.price}
                  </span>
                  {plan.period && (
                    <span className="text-slate-600">{plan.period}</span>
                  )}
                </div>
                <ul className="mt-8 space-y-4">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-3">
                      <Check className="h-5 w-5 text-green-600" />
                      <span className="text-slate-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                <button
                  className={`mt-8 w-full rounded py-2 font-medium ${
                    plan.highlighted
                      ? "bg-red-600 text-white hover:bg-red-700"
                      : "border border-slate-300 text-slate-900 hover:bg-slate-50"
                  }`}
                >
                  Get Started
                </button>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Link
              href="/pricing"
              className="inline-flex items-center gap-2 text-red-600 hover:text-red-700"
            >
              View full pricing and compare plans
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="border-b border-slate-200 bg-slate-900 py-16 text-white">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold">
            Start processing PDFs for free today
          </h2>
          <p className="mt-4 text-lg text-slate-300">
            No credit card required. Access core tools instantly.
          </p>
          <Link
            href="/signup"
            className="mt-8 inline-flex items-center gap-2 rounded bg-red-600 px-8 py-3 font-medium text-white hover:bg-red-700"
          >
            Get Started
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white py-12">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-5">
            <div>
              <h3 className="font-semibold text-slate-900">Product</h3>
              <ul className="mt-4 space-y-2">
                <li>
                  <a href="/tools" className="text-sm text-slate-600 hover:text-slate-900">
                    PDF Tools
                  </a>
                </li>
                <li>
                  <a href="/ai-pdf" className="text-sm text-slate-600 hover:text-slate-900">
                    AI PDF
                  </a>
                </li>
                <li>
                  <a href="/pricing" className="text-sm text-slate-600 hover:text-slate-900">
                    Pricing
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-slate-900">Resources</h3>
              <ul className="mt-4 space-y-2">
                <li>
                  <a href="/help" className="text-sm text-slate-600 hover:text-slate-900">
                    Help Center
                  </a>
                </li>
                <li>
                  <a href="/blog" className="text-sm text-slate-600 hover:text-slate-900">
                    Blog
                  </a>
                </li>
                <li>
                  <a href="/api" className="text-sm text-slate-600 hover:text-slate-900">
                    API Docs
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-slate-900">Company</h3>
              <ul className="mt-4 space-y-2">
                <li>
                  <a href="/about" className="text-sm text-slate-600 hover:text-slate-900">
                    About
                  </a>
                </li>
                <li>
                  <a href="/contact" className="text-sm text-slate-600 hover:text-slate-900">
                    Contact
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-slate-900">Legal</h3>
              <ul className="mt-4 space-y-2">
                <li>
                  <a href="/privacy" className="text-sm text-slate-600 hover:text-slate-900">
                    Privacy
                  </a>
                </li>
                <li>
                  <a href="/terms" className="text-sm text-slate-600 hover:text-slate-900">
                    Terms
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-slate-900">Security</h3>
              <ul className="mt-4 space-y-2">
                <li>
                  <a href="/security" className="text-sm text-slate-600 hover:text-slate-900">
                    Security
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-12 border-t border-slate-200 pt-8">
            <p className="text-center text-sm text-slate-600">
              © 2024 LOVE PDF. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </>
  );
}
