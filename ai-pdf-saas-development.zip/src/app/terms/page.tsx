import { Metadata } from "next";
import Link from "next/link";
import { Sparkles } from "lucide-react";

export const metadata: Metadata = {
  title: "Terms of Service - LOVE PDF",
  description: "Terms of service for LOVE PDF",
};

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navbar */}
      <nav className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded bg-red-600">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="font-bold text-slate-900">LOVE PDF</span>
            </Link>
          </div>
        </div>
      </nav>

      {/* Content */}
      <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-slate-900">Terms of Service</h1>
        <p className="mt-2 text-slate-600">Last updated: January 2024</p>

        <div className="prose prose-slate mt-8 max-w-none">
          <h2>1. Agreement to Terms</h2>
          <p>
            By accessing and using LOVE PDF ("Service"), you accept and agree to be
            bound by the terms and provision of this agreement.
          </p>

          <h2>2. Use License</h2>
          <p>
            Permission is granted to temporarily download one copy of the materials
            (information or software) on LOVE PDF for personal, non-commercial
            transitory viewing only. This is the grant of a license, not a transfer of
            title, and under this license you may not:
          </p>
          <ul>
            <li>Modify or copy the materials</li>
            <li>Use the materials for any commercial purpose or for any public display</li>
            <li>Attempt to decompile or reverse engineer any software contained on the Service</li>
            <li>Remove any copyright or other proprietary notations from the materials</li>
            <li>Transfer the materials to another person or "mirror" the materials on any other server</li>
          </ul>

          <h2>3. Disclaimer</h2>
          <p>
            The materials on LOVE PDF are provided on an 'as is' basis. LOVE PDF makes
            no warranties, expressed or implied, and hereby disclaims and negates all
            other warranties including, without limitation, implied warranties or
            conditions of merchantability, fitness for a particular purpose, or
            non-infringement of intellectual property or other violation of rights.
          </p>

          <h2>4. Limitations</h2>
          <p>
            In no event shall LOVE PDF or its suppliers be liable for any damages
            (including, without limitation, damages for loss of data or profit, or
            due to business interruption) arising out of the use or inability to use
            the materials on LOVE PDF.
          </p>

          <h2>5. Accuracy of Materials</h2>
          <p>
            The materials appearing on LOVE PDF could include technical, typographical,
            or photographic errors. LOVE PDF does not warrant that any of the materials
            on its Service are accurate, complete, or current.
          </p>

          <h2>6. Materials and Content</h2>
          <p>
            You are responsible for all content you upload to LOVE PDF. You warrant and
            represent that you own or have the necessary rights to the content you submit.
          </p>

          <h2>7. Acceptable Use</h2>
          <p>You agree not to use the Service to:</p>
          <ul>
            <li>Upload illegal content</li>
            <li>Engage in harassment or abuse</li>
            <li>Transmit viruses or malware</li>
            <li>Attempt to gain unauthorized access</li>
            <li>Violate any applicable laws or regulations</li>
          </ul>

          <h2>8. Subscription and Billing</h2>
          <p>
            Subscription plans renew automatically unless cancelled. You may cancel
            your subscription at any time. Billing continues until cancellation.
          </p>

          <h2>9. Refunds</h2>
          <p>
            All payments are final and non-refundable except as required by law. We
            may issue refunds at our sole discretion for disputed charges.
          </p>

          <h2>10. Modifications to Service</h2>
          <p>
            LOVE PDF reserves the right to modify or discontinue the Service at any
            time with or without notice to you.
          </p>

          <h2>11. Termination</h2>
          <p>
            We may terminate or suspend your account and access to the Service
            immediately, without prior notice or liability, if you breach any terms of
            this Agreement.
          </p>

          <h2>12. Governing Law</h2>
          <p>
            These terms and conditions are governed by and construed in accordance with
            the laws of the jurisdiction in which the company operates.
          </p>

          <h2>13. Contact Information</h2>
          <p>
            If you have any questions about these Terms of Service, please contact us
            at: legal@lovepdf.com
          </p>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-12">
        <div className="mx-auto max-w-6xl px-4 text-center sm:px-6 lg:px-8">
          <p className="text-slate-600">© 2024 LOVE PDF. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
