import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "LOVE PDF - Powerful PDF Tools. Simple by Design.",
  description:
    "Merge, compress, convert, edit, sign and understand your PDFs with one fast, secure workspace.",
  keywords: [
    "PDF",
    "merge PDF",
    "compress PDF",
    "convert PDF",
    "edit PDF",
    "PDF tools",
    "online PDF",
  ],
  authors: [{ name: "LOVE PDF" }],
  openGraph: {
    title: "LOVE PDF - Powerful PDF Tools. Simple by Design.",
    description:
      "Merge, compress, convert, edit, sign and understand your PDFs with one fast, secure workspace.",
    type: "website",
    locale: "en_US",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta name="theme-color" content="#172033" />
        <meta name="mobile-web-app-capable" content="yes" />
      </head>
      <body className="bg-slate-50 text-slate-900 antialiased">
        {children}
      </body>
    </html>
  );
}
