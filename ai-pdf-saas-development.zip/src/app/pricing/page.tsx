import { Metadata } from "next";
import Link from "next/link";
import { Sparkles, Check, ArrowRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Pricing - LOVE PDF",
  description: "Simple, transparent pricing for all your PDF needs",
};

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navbar */}
      <nav className="sticky top-0 z-40 border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded bg-red-600">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="font-bold text-slate-900">LOVE PDF</span>
            </Link>

            <div className="hidden items-center gap-8 md:flex">
              <a href="/tools" className="text-sm text-slate-600 hover:text-slate-900">
                Tools
              </a>
              <a href="/pricing" className="text-sm text-slate-600 hover:text-slate-900">
                Pricing
              </a>
            </div>

            <div className="flex items-center gap-4">
              <Link href="/login" className="hidden text-sm text-slate-600 hover:text-slate-900 md:block">
                Login
              </Link>
              <Link
                href="/signup"
                className="rounded bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700"
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="border-b border-slate-200 bg-white py-16">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold text-slate-900">
            Simple, Transparent Pricing
          </h1>
          <p className="mt-4 text-xl text-slate-600">
            Choose the plan that fits your needs. No hidden fees.
          </p>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-3">
            {[
              {
                name: "Free",
                price: "$0",
                period: "Forever free",
                description: "Perfect for occasional use",
                cta: "Get Started Free",
                ctaHref: "/signup",
                features: [
                  "5 tasks per day",
                  "25 MB file size",
                  "Basic PDF tools",
                  "No ads",
                  "Web access",
                ],
                notIncluded: [
                  "OCR & Editor",
                  "AI PDF",
                  "Priority processing",
                  "Cloud storage",
                ],
              },
              {
                name: "Pro",
                price: "$5.99",
                period: "per month",
                description: "For regular PDF users",
                cta: "Start Pro Trial",
                ctaHref: "/signup?plan=pro",
                highlighted: true,
                features: [
                  "250 MB file size",
                  "50+ tools",
                  "OCR & PDF Editor",
                  "AI PDF (100 req/month)",
                  "Cloud storage (2 GB)",
                  "No ads",
                  "Priority processing",
                ],
                notIncluded: ["Team workspace", "API access", "Admin controls"],
              },
              {
                name: "Business",
                price: "$12.99",
                period: "per user/month",
                description: "For teams and enterprises",
                cta: "Start Business Trial",
                ctaHref: "/signup?plan=business",
                features: [
                  "1 GB file size",
                  "Everything in Pro",
                  "Team workspace",
                  "Shared documents",
                  "Team management",
                  "Audit logs",
                  "API access",
                  "Cloud storage (10 GB)",
                ],
                notIncluded: [],
              },
            ].map((plan) => (
              <div
                key={plan.name}
                className={`flex flex-col rounded-lg border p-8 ${
                  plan.highlighted
                    ? "border-red-600 bg-red-50 shadow-lg"
                    : "border-slate-200 bg-white"
                }`}
              >
                {plan.highlighted && (
                  <div className="mb-4 inline-block w-fit rounded-full bg-red-600 px-3 py-1 text-xs font-bold text-white">
                    MOST POPULAR
                  </div>
                )}

                <h3 className="text-2xl font-bold text-slate-900">
                  {plan.name}
                </h3>
                <p className="mt-2 text-sm text-slate-600">
                  {plan.description}
                </p>

                <div className="mt-6 flex items-baseline gap-1">
                  <span className="text-5xl font-bold text-slate-900">
                    {plan.price}
                  </span>
                  <span className="text-slate-600">{plan.period}</span>
                </div>

                <Link
                  href={plan.ctaHref}
                  className={`mt-8 w-full rounded-lg py-3 font-medium inline-flex items-center justify-center gap-2 ${
                    plan.highlighted
                      ? "bg-red-600 text-white hover:bg-red-700"
                      : "border border-slate-300 text-slate-900 hover:bg-slate-50"
                  }`}
                >
                  {plan.cta}
                  <ArrowRight className="h-4 w-4" />
                </Link>

                <div className="mt-8 space-y-4">
                  <p className="text-sm font-semibold text-slate-900">
                    Included:
                  </p>
                  {plan.features.map((feature) => (
                    <div key={feature} className="flex items-start gap-3">
                      <Check className="mt-0.5 h-5 w-5 flex-shrink-0 text-green-600" />
                      <span className="text-sm text-slate-700">{feature}</span>
                    </div>
                  ))}

                  {plan.notIncluded.length > 0 && (
                    <>
                      <p className="pt-4 text-sm font-semibold text-slate-900">
                        Not included:
                      </p>
                      {plan.notIncluded.map((feature) => (
                        <div key={feature} className="flex items-start gap-3">
                          <div className="mt-0.5 h-5 w-5 flex-shrink-0 text-slate-300" />
                          <span className="text-sm text-slate-500">
                            {feature}
                          </span>
                        </div>
                      ))}
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="border-t border-slate-200 bg-white py-16">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-3xl font-bold text-slate-900">
            Frequently Asked Questions
          </h2>

          <div className="mt-12 space-y-6">
            {[
              {
                q: "Can I change plans anytime?",
                a: "Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately.",
              },
              {
                q: "Do you offer annual discounts?",
                a: "Yes! Pro plans are $59/year (save $12/year) and Business is $129/user/year (save $26/year).",
              },
              {
                q: "What payment methods do you accept?",
                a: "We accept all major credit cards (Visa, Mastercard, American Express) and process payments securely through Stripe.",
              },
              {
                q: "Is there a free trial for Pro and Business?",
                a: "Yes, you get a 7-day free trial for both Pro and Business plans with full access to all features.",
              },
              {
                q: "What happens if I exceed my limits?",
                a: "On Free plans, you'll need to wait for the daily reset or upgrade. Pro and Business plans have generous limits.",
              },
              {
                q: "Can I cancel anytime?",
                a: "Yes, cancel anytime with no penalties. Your access continues until the end of your billing period.",
              },
            ].map((item, idx) => (
              <div key={idx} className="rounded-lg border border-slate-200 p-6">
                <h3 className="font-semibold text-slate-900">{item.q}</h3>
                <p className="mt-2 text-slate-600">{item.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-slate-200 bg-slate-900 py-16 text-white">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold">Start processing PDFs today</h2>
          <p className="mt-4 text-lg text-slate-300">
            No credit card required for Free plan
          </p>
          <Link
            href="/signup"
            className="mt-8 inline-flex items-center gap-2 rounded-lg bg-red-600 px-8 py-3 font-medium text-white hover:bg-red-700"
          >
            Get Started Free
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white py-12 border-t border-slate-200">
        <div className="mx-auto max-w-6xl px-4 text-center sm:px-6 lg:px-8">
          <p className="text-slate-600">© 2024 LOVE PDF. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
