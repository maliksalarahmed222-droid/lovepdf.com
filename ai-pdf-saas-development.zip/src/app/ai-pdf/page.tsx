import { Metadata } from "next";
import Link from "next/link";
import { Sparkles, Upload, ArrowRight, Zap, Brain, FileText } from "lucide-react";

export const metadata: Metadata = {
  title: "AI PDF - Ask Questions About Your Documents | LOVE PDF",
  description:
    "Use AI to extract information, summarize documents, and find specific content instantly.",
};

export default function AIPDFPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navbar */}
      <nav className="sticky top-0 z-40 border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded bg-red-600">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="font-bold text-slate-900">LOVE PDF</span>
            </Link>

            <div className="hidden items-center gap-8 md:flex">
              <a href="/tools" className="text-sm text-slate-600 hover:text-slate-900">
                Tools
              </a>
              <a href="/ai-pdf" className="text-sm text-slate-600 hover:text-slate-900">
                AI PDF
              </a>
            </div>

            <div className="flex items-center gap-4">
              <Link href="/login" className="hidden text-sm text-slate-600 hover:text-slate-900 md:block">
                Login
              </Link>
              <Link
                href="/signup"
                className="rounded bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700"
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="border-b border-slate-200 bg-white py-20">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <div className="inline-flex items-center gap-2 rounded-full bg-red-100 px-4 py-2">
            <Sparkles className="h-4 w-4 text-red-600" />
            <span className="text-sm font-medium text-red-600">
              Powered by Advanced AI
            </span>
          </div>

          <h1 className="mt-6 text-5xl font-bold text-slate-900">
            Ask Questions About Your PDFs
          </h1>
          <p className="mt-6 text-xl text-slate-600">
            Upload any document and let AI help you extract information,
            summarize content, and find exactly what you need in seconds.
          </p>

          <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:justify-center">
            <Link
              href="/signup"
              className="inline-flex items-center justify-center gap-2 rounded bg-red-600 px-8 py-3 font-medium text-white hover:bg-red-700"
            >
              Try AI PDF Free
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              href="/pricing"
              className="inline-flex items-center justify-center rounded border border-slate-300 px-8 py-3 font-medium text-slate-900 hover:bg-slate-50"
            >
              View Pricing
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-slate-50 py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-3xl font-bold text-slate-900">
            What AI PDF Can Do
          </h2>

          <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: Brain,
                title: "Summarize Documents",
                description: "Get quick summaries of long documents in seconds",
              },
              {
                icon: FileText,
                title: "Extract Information",
                description:
                  "Find names, dates, amounts, and important details automatically",
              },
              {
                icon: Zap,
                title: "Answer Questions",
                description:
                  "Ask AI questions and get answers directly from your PDF",
              },
              {
                icon: Upload,
                title: "Process Any PDF",
                description: "Works with contracts, reports, invoices, and more",
              },
              {
                icon: Sparkles,
                title: "Instant Insights",
                description: "Get key points and important information highlighted",
              },
              {
                icon: ArrowRight,
                title: "Save Time",
                description: "Spend less time reading, more time doing",
              },
            ].map((feature) => {
              const Icon = feature.icon;
              return (
                <div key={feature.title} className="rounded-lg bg-white p-8">
                  <Icon className="h-8 w-8 text-red-600" />
                  <h3 className="mt-4 font-semibold text-slate-900">
                    {feature.title}
                  </h3>
                  <p className="mt-2 text-slate-600">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Example Use Cases */}
      <section className="border-y border-slate-200 bg-white py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-3xl font-bold text-slate-900">
            Perfect For
          </h2>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[
              "Reading long reports",
              "Understanding contracts",
              "Analyzing financial documents",
              "Reviewing legal agreements",
              "Summarizing research papers",
              "Extracting invoice details",
              "Processing forms",
              "Finding specific information",
              "Comparing documents",
            ].map((useCase) => (
              <div
                key={useCase}
                className="flex items-center gap-3 rounded-lg bg-slate-50 p-4"
              >
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-red-100">
                  <Sparkles className="h-4 w-4 text-red-600" />
                </div>
                <span className="font-medium text-slate-900">{useCase}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="bg-slate-50 py-16">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-3xl font-bold text-slate-900">
            How It Works
          </h2>

          <div className="mt-12 grid gap-8 sm:grid-cols-3">
            {[
              { step: "1", title: "Upload", desc: "Select your PDF file" },
              { step: "2", title: "Ask", desc: "Question the AI about content" },
              { step: "3", title: "Get Answers", desc: "Instant AI responses" },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-red-600 text-white font-bold">
                  {item.step}
                </div>
                <h3 className="mt-4 font-semibold text-slate-900">
                  {item.title}
                </h3>
                <p className="mt-2 text-sm text-slate-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Privacy Notice */}
      <section className="border-t border-slate-200 bg-white py-16">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="rounded-lg border border-yellow-200 bg-yellow-50 p-6">
            <h3 className="font-semibold text-yellow-900">Privacy First</h3>
            <p className="mt-2 text-sm text-yellow-800">
              Your PDFs are processed securely and deleted automatically after
              processing. We never store your documents or use them for training
              AI models. You maintain complete control over your files.
            </p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-slate-200 bg-slate-900 py-16 text-white">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold">
            Ready to supercharge your PDF workflow?
          </h2>
          <Link
            href="/signup"
            className="mt-8 inline-flex items-center gap-2 rounded-lg bg-red-600 px-8 py-3 font-medium text-white hover:bg-red-700"
          >
            Try AI PDF Now
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white py-12 border-t border-slate-200">
        <div className="mx-auto max-w-6xl px-4 text-center sm:px-6 lg:px-8">
          <p className="text-slate-600">© 2024 LOVE PDF. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
