import { Metadata } from "next";
import Link from "next/link";
import {
  Sparkles,
  Merge,
  Package,
  FileUp,
  FileDown,
  Edit3,
  Lock,
  PenTool,
  Eye,
  ArrowRight,
} from "lucide-react";

export const metadata: Metadata = {
  title: "PDF Tools - 56 Powerful Tools | LOVE PDF",
  description:
    "Merge, compress, convert, edit, and secure your PDFs with our comprehensive suite of tools.",
};

const TOOLS = [
  {
    category: "Organize PDF",
    icon: Merge,
    tools: [
      { name: "Merge PDF", href: "/merge-pdf" },
      { name: "Split PDF", href: "/split-pdf" },
      { name: "Extract Pages", href: "/extract-pages" },
      { name: "Delete Pages", href: "/delete-pages" },
      { name: "Rearrange Pages", href: "/rearrange-pages" },
      { name: "Rotate PDF", href: "/rotate-pdf" },
      { name: "Duplicate Pages", href: "/duplicate-pages" },
      { name: "Add Page Numbers", href: "/add-page-numbers" },
      { name: "PDF Booklet", href: "/pdf-booklet" },
    ],
  },
  {
    category: "Optimize PDF",
    icon: Package,
    tools: [
      { name: "Compress PDF", href: "/compress-pdf" },
      { name: "Optimize PDF", href: "/optimize-pdf" },
      { name: "Repair PDF", href: "/repair-pdf" },
      { name: "Flatten PDF", href: "/flatten-pdf" },
      { name: "Reduce PDF Size", href: "/reduce-pdf-size" },
    ],
  },
  {
    category: "Convert to PDF",
    icon: FileUp,
    tools: [
      { name: "JPG to PDF", href: "/jpg-to-pdf" },
      { name: "PNG to PDF", href: "/png-to-pdf" },
      { name: "WebP to PDF", href: "/webp-to-pdf" },
      { name: "Word to PDF", href: "/word-to-pdf" },
      { name: "Excel to PDF", href: "/excel-to-pdf" },
      { name: "PowerPoint to PDF", href: "/ppt-to-pdf" },
      { name: "HTML to PDF", href: "/html-to-pdf" },
      { name: "Text to PDF", href: "/text-to-pdf" },
      { name: "TIFF to PDF", href: "/tiff-to-pdf" },
    ],
  },
  {
    category: "Convert from PDF",
    icon: FileDown,
    tools: [
      { name: "PDF to JPG", href: "/pdf-to-jpg" },
      { name: "PDF to PNG", href: "/pdf-to-png" },
      { name: "PDF to WebP", href: "/pdf-to-webp" },
      { name: "PDF to Word", href: "/pdf-to-word" },
      { name: "PDF to Excel", href: "/pdf-to-excel" },
      { name: "PDF to PowerPoint", href: "/pdf-to-ppt" },
      { name: "PDF to Text", href: "/pdf-to-text" },
      { name: "PDF to HTML", href: "/pdf-to-html" },
      { name: "PDF to PDF/A", href: "/pdf-to-pdfa" },
    ],
  },
  {
    category: "Edit PDF",
    icon: Edit3,
    tools: [
      { name: "Edit PDF", href: "/edit-pdf" },
      { name: "Add Text", href: "/add-text" },
      { name: "Add Image", href: "/add-image" },
      { name: "Add Shape", href: "/add-shape" },
      { name: "Highlight", href: "/highlight" },
      { name: "Draw", href: "/draw" },
      { name: "Add Comment", href: "/add-comment" },
      { name: "Add Link", href: "/add-link" },
      { name: "Whiteout", href: "/whiteout" },
      { name: "Redact", href: "/redact" },
    ],
  },
  {
    category: "PDF Security",
    icon: Lock,
    tools: [
      { name: "Protect PDF", href: "/protect-pdf" },
      { name: "Unlock PDF", href: "/unlock-pdf" },
      { name: "Encrypt PDF", href: "/encrypt-pdf" },
      { name: "Remove Password", href: "/remove-password" },
      { name: "Remove Metadata", href: "/remove-metadata" },
    ],
  },
  {
    category: "Sign PDF",
    icon: PenTool,
    tools: [
      { name: "Sign PDF", href: "/sign-pdf" },
      { name: "Request Signature", href: "/request-signature" },
    ],
  },
  {
    category: "OCR & AI",
    icon: Eye,
    tools: [
      { name: "OCR PDF", href: "/ocr-pdf" },
      { name: "Image OCR", href: "/image-ocr" },
      { name: "Make Searchable", href: "/make-searchable" },
      { name: "AI PDF", href: "/ai-pdf" },
      { name: "Summarize", href: "/summarize" },
      { name: "Extract Info", href: "/extract-info" },
    ],
  },
];

export default function ToolsPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navbar */}
      <nav className="sticky top-0 z-40 border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded bg-red-600">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="font-bold text-slate-900">LOVE PDF</span>
            </Link>

            <div className="hidden items-center gap-8 md:flex">
              <a href="/tools" className="text-sm font-medium text-red-600">
                Tools
              </a>
              <a href="/ai-pdf" className="text-sm text-slate-600 hover:text-slate-900">
                AI PDF
              </a>
            </div>

            <div className="flex items-center gap-4">
              <Link href="/login" className="hidden text-sm text-slate-600 hover:text-slate-900 md:block">
                Login
              </Link>
              <Link
                href="/signup"
                className="rounded bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700"
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="border-b border-slate-200 bg-white py-12">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold text-slate-900">56 PDF Tools</h1>
          <p className="mt-2 text-slate-600">
            Everything you need for your PDF documents
          </p>
        </div>
      </section>

      {/* Tools by Category */}
      <section className="py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="space-y-12">
            {TOOLS.map((category) => {
              const Icon = category.icon;
              return (
                <div key={category.category}>
                  <div className="mb-6 flex items-center gap-3">
                    <Icon className="h-6 w-6 text-red-600" />
                    <h2 className="text-2xl font-bold text-slate-900">
                      {category.category}
                    </h2>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    {category.tools.map((tool) => (
                      <Link
                        key={tool.href}
                        href={tool.href}
                        className="flex items-center justify-between rounded-lg border border-slate-200 bg-white p-4 transition hover:shadow-lg"
                      >
                        <span className="font-medium text-slate-900">
                          {tool.name}
                        </span>
                        <ArrowRight className="h-4 w-4 text-slate-400" />
                      </Link>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-slate-200 bg-slate-900 py-16 text-white">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold">Start using PDF tools today</h2>
          <p className="mt-4 text-lg text-slate-300">
            No sign-up required for basic tools
          </p>
          <Link
            href="/merge-pdf"
            className="mt-8 inline-flex items-center gap-2 rounded-lg bg-red-600 px-8 py-3 font-medium text-white hover:bg-red-700"
          >
            Try a Tool Free
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white py-12 border-t border-slate-200">
        <div className="mx-auto max-w-6xl px-4 text-center sm:px-6 lg:px-8">
          <p className="text-slate-600">© 2024 LOVE PDF. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
