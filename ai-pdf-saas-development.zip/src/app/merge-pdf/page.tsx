"use client";

import { useState, useRef } from "react";
import Link from "next/link";
import { Sparkles, Upload, X, Download, ArrowRight, Loader2 } from "lucide-react";
import { formatBytes } from "@/lib/utils";

interface UploadedFile {
  id: string;
  file: File;
  name: string;
  size: string;
}

export default function MergePDFPage() {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<{
    filename: string;
    size: string;
    sizeFormatted: string;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dragCounter = useRef(0);
  const [isDragActive, setIsDragActive] = useState(false);

  function handleDrag(e: React.DragEvent) {
    e.preventDefault();
    e.stopPropagation();
  }

  function handleDragIn(e: React.DragEvent) {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current++;
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      setIsDragActive(true);
    }
  }

  function handleDragOut(e: React.DragEvent) {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current--;
    if (dragCounter.current === 0) {
      setIsDragActive(false);
    }
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current = 0;
    setIsDragActive(false);

    if (e.dataTransfer.files) {
      const newFiles = Array.from(e.dataTransfer.files).filter(
        (file) => file.type === "application/pdf"
      );
      addFiles(newFiles);
    }
  }

  function addFiles(fileList: File[]) {
    const newFiles = fileList.map((file) => ({
      id: Math.random().toString(36).substr(2, 9),
      file,
      name: file.name,
      size: formatBytes(file.size),
    }));
    setFiles((prev) => [...prev, ...newFiles]);
    setError("");
  }

  function handleFileInput(e: React.ChangeEvent<HTMLInputElement>) {
    if (e.target.files) {
      addFiles(Array.from(e.target.files));
    }
  }

  function removeFile(id: string) {
    setFiles((prev) => prev.filter((f) => f.id !== id));
  }

  async function handleMerge() {
    if (files.length < 2) {
      setError("Please upload at least 2 PDF files");
      return;
    }

    setIsProcessing(true);
    setError("");

    try {
      const formData = new FormData();
      files.forEach((f) => formData.append("files", f.file));

      const response = await fetch("/api/tools/merge-pdf", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const data = await response.json();
        setError(data.error || "Merge failed");
        setIsProcessing(false);
        return;
      }

      const data = await response.json();
      setResult({
        filename: data.resultFile.filename,
        size: String(data.resultFile.size),
        sizeFormatted: data.resultFile.sizeFormatted,
      });
      setFiles([]);
    } catch (err) {
      setError("An error occurred. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  }

  async function downloadResult() {
    if (!result) return;

    try {
      const response = await fetch(`/api/files/${result.filename}/download`);
      if (!response.ok) throw new Error("Download failed");

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = result.filename;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      setError("Download failed");
    }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navbar */}
      <nav className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded bg-red-600">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="font-bold text-slate-900">LOVE PDF</span>
            </Link>

            <div className="flex items-center gap-4">
              <Link href="/dashboard" className="text-sm text-slate-600 hover:text-slate-900">
                Dashboard
              </Link>
              <Link
                href="/login"
                className="rounded bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700"
              >
                Sign in
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Content */}
      <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900">Merge PDF</h1>
          <p className="mt-2 text-slate-600">
            Combine multiple PDF files into one document
          </p>
        </div>

        {error && (
          <div className="mb-8 rounded-lg bg-red-50 p-4">
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}

        {!result ? (
          <div className="space-y-8">
            {/* Upload Area */}
            <div
              onDragOver={handleDrag}
              onDragEnter={handleDragIn}
              onDragLeave={handleDragOut}
              onDrop={handleDrop}
              className={`rounded-lg border-2 border-dashed p-12 text-center transition ${
                isDragActive
                  ? "border-red-500 bg-red-50"
                  : "border-slate-300 bg-white"
              }`}
            >
              <Upload className="mx-auto h-12 w-12 text-slate-400" />
              <p className="mt-4 font-medium text-slate-900">
                Drop your PDF files here
              </p>
              <p className="mt-2 text-sm text-slate-600">
                or click below to browse
              </p>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept=".pdf"
                onChange={handleFileInput}
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="mt-6 rounded-lg bg-red-600 px-6 py-2 font-medium text-white hover:bg-red-700"
              >
                Choose Files
              </button>
            </div>

            {/* File List */}
            {files.length > 0 && (
              <div className="rounded-lg border border-slate-200 bg-white p-6">
                <h3 className="font-semibold text-slate-900">
                  Selected files ({files.length})
                </h3>
                <div className="mt-4 space-y-2">
                  {files.map((file, index) => (
                    <div
                      key={file.id}
                      className="flex items-center justify-between rounded-lg bg-slate-50 p-4"
                    >
                      <div className="flex items-center gap-3">
                        <span className="flex h-8 w-8 items-center justify-center rounded bg-red-100 text-sm font-bold text-red-600">
                          {index + 1}
                        </span>
                        <div>
                          <p className="font-medium text-slate-900">
                            {file.name}
                          </p>
                          <p className="text-sm text-slate-500">{file.size}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => removeFile(file.id)}
                        className="text-slate-400 hover:text-slate-600"
                      >
                        <X className="h-5 w-5" />
                      </button>
                    </div>
                  ))}
                </div>

                <button
                  onClick={handleMerge}
                  disabled={isProcessing || files.length < 2}
                  className="mt-6 w-full rounded-lg bg-red-600 py-3 font-medium text-white hover:bg-red-700 disabled:bg-slate-300 flex items-center justify-center gap-2"
                >
                  {isProcessing && (
                    <Loader2 className="h-5 w-5 animate-spin" />
                  )}
                  {isProcessing ? "Merging PDFs..." : "Merge PDFs"}
                </button>
              </div>
            )}
          </div>
        ) : (
          // Result Section
          <div className="rounded-lg border border-slate-200 bg-white p-8 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
              <ArrowRight className="h-8 w-8 text-green-600" />
            </div>
            <h2 className="mt-6 text-2xl font-bold text-slate-900">
              Your PDF is ready!
            </h2>
            <p className="mt-2 text-slate-600">
              {result.sizeFormatted} • Ready to download
            </p>

            <button
              onClick={downloadResult}
              className="mt-8 inline-flex items-center gap-2 rounded-lg bg-red-600 px-8 py-3 font-medium text-white hover:bg-red-700"
            >
              <Download className="h-5 w-5" />
              Download PDF
            </button>

            <button
              onClick={() => {
                setResult(null);
                setFiles([]);
              }}
              className="mt-4 inline-flex items-center gap-2 rounded-lg border border-slate-300 px-8 py-3 font-medium text-slate-900 hover:bg-slate-50"
            >
              Merge Another PDF
            </button>
          </div>
        )}

        {/* How it Works */}
        <div className="mt-16 rounded-lg border border-slate-200 bg-white p-8">
          <h3 className="text-lg font-bold text-slate-900">How it works</h3>
          <ol className="mt-6 space-y-4">
            <li className="flex gap-4">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-red-100 text-sm font-bold text-red-600">
                1
              </span>
              <div>
                <p className="font-medium text-slate-900">Upload PDF files</p>
                <p className="text-sm text-slate-600">
                  Select 2 or more PDF files from your device
                </p>
              </div>
            </li>
            <li className="flex gap-4">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-red-100 text-sm font-bold text-red-600">
                2
              </span>
              <div>
                <p className="font-medium text-slate-900">Reorder if needed</p>
                <p className="text-sm text-slate-600">
                  Arrange the files in your preferred order
                </p>
              </div>
            </li>
            <li className="flex gap-4">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-red-100 text-sm font-bold text-red-600">
                3
              </span>
              <div>
                <p className="font-medium text-slate-900">Click merge</p>
                <p className="text-sm text-slate-600">
                  We'll combine all your PDFs into one
                </p>
              </div>
            </li>
            <li className="flex gap-4">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-red-100 text-sm font-bold text-red-600">
                4
              </span>
              <div>
                <p className="font-medium text-slate-900">Download</p>
                <p className="text-sm text-slate-600">
                  Get your merged PDF instantly
                </p>
              </div>
            </li>
          </ol>
        </div>
      </div>
    </div>
  );
}
