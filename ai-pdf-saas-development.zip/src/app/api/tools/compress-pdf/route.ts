import { NextRequest, NextResponse } from "next/server";
import { writeFile, unlink } from "fs/promises";
import { v4 as uuidv4 } from "uuid";
import { compressPDF, getTempFilePath } from "@/lib/pdf-processor";
import { db } from "@/db";
import { files, processingJobs } from "@/db/schema";
import { formatBytes } from "@/lib/utils";
import { statSync } from "fs";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    // Parse form data
    const formData = await req.formData();
    const pdfFile = formData.get("file") as File | null;

    if (!pdfFile) {
      return NextResponse.json(
        { error: "No PDF file provided" },
        { status: 400 }
      );
    }

    if (pdfFile.type !== "application/pdf") {
      return NextResponse.json(
        { error: "File must be a PDF" },
        { status: 400 }
      );
    }

    // Create job record (no user required for guest)
    const job = await db
      .insert(processingJobs)
      .values({
        toolType: "COMPRESS",
        status: "PROCESSING",
        parameters: { quality: "recommended" },
      })
      .returning();

    const jobId = job[0].id;

    try {
      // Save uploaded file to temp directory
      const buffer = await pdfFile.arrayBuffer();
      const inputPath = getTempFilePath(`${uuidv4()}.pdf`);
      await writeFile(inputPath, Buffer.from(buffer));

      // Get original size
      const originalStats = statSync(inputPath);
      const originalSize = originalStats.size;

      // Compress PDF
      const outputFilename = `compressed-${uuidv4()}.pdf`;
      const outputPath = getTempFilePath(outputFilename);

      const startTime = Date.now();
      await compressPDF(inputPath, outputPath);
      const processingTime = Date.now() - startTime;

      // Get compressed size
      const compressedStats = statSync(outputPath);
      const compressedSize = compressedStats.size;
      const savedPercent = Math.round(
        ((originalSize - compressedSize) / originalSize) * 100
      );

      // Update job as completed
      await db
        .update(processingJobs)
        .set({
          status: "COMPLETED",
          processingTimeMs: processingTime,
          completedAt: new Date(),
        })
        .where(eq(processingJobs.id, jobId));

      // Clean up input file
      try {
        await unlink(inputPath);
      } catch (e) {
        // Ignore cleanup errors
      }

      return NextResponse.json({
        success: true,
        jobId,
        resultFile: {
          filename: outputFilename,
          originalSize,
          originalSizeFormatted: formatBytes(originalSize),
          compressedSize,
          compressedSizeFormatted: formatBytes(compressedSize),
          savedBytes: originalSize - compressedSize,
          savedPercent,
          processingTimeMs: processingTime,
        },
      });
    } catch (error) {
      // Update job as failed
      const errorMessage =
        error instanceof Error ? error.message : "Unknown error";
      await db
        .update(processingJobs)
        .set({
          status: "FAILED",
          errorMessage,
          completedAt: new Date(),
        })
        .where(eq(processingJobs.id, jobId));

      return NextResponse.json(
        { error: errorMessage },
        { status: 500 }
      );
    }
  } catch (error) {
    console.error("Compress PDF error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
