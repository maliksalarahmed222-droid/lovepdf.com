import { NextRequest, NextResponse } from "next/server";
import { writeFile, unlink } from "fs/promises";
import { v4 as uuidv4 } from "uuid";
import { getUserFromSession } from "@/lib/auth";
import { mergePDFs, getTempFilePath } from "@/lib/pdf-processor";
import { db } from "@/db";
import { files, processingJobs } from "@/db/schema";
import { formatBytes } from "@/lib/utils";
import { statSync } from "fs";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    // Parse form data
    const formData = await req.formData();
    const pdfFiles = formData.getAll("files") as File[];

    if (!pdfFiles.length) {
      return NextResponse.json(
        { error: "No PDF files provided" },
        { status: 400 }
      );
    }

    // Check authentication (optional - support guest users too)
    const user = await getUserFromSession();

    // Create job record
    const job = await db
      .insert(processingJobs)
      .values({
        userId: user?.id || undefined,
        toolType: "MERGE",
        status: "PROCESSING",
        parameters: { count: pdfFiles.length },
      })
      .returning();

    const jobId = job[0].id;

    try {
      // Save uploaded files to temp directory
      const tempInputPaths: string[] = [];
      for (const pdfFile of pdfFiles) {
        const buffer = await pdfFile.arrayBuffer();
        const tempPath = getTempFilePath(`${uuidv4()}.pdf`);
        await writeFile(tempPath, Buffer.from(buffer));
        tempInputPaths.push(tempPath);
      }

      // Merge PDFs
      const outputFilename = `merged-${uuidv4()}.pdf`;
      const outputPath = getTempFilePath(outputFilename);

      const startTime = Date.now();
      await mergePDFs(tempInputPaths, outputPath);
      const processingTime = Date.now() - startTime;

      // Get file size
      const fileStats = statSync(outputPath);
      const fileSize = fileStats.size;

      // Update job as completed
      await db
        .update(processingJobs)
        .set({
          status: "COMPLETED",
          processingTimeMs: processingTime,
          completedAt: new Date(),
        })
        .where(eq(processingJobs.id, jobId));

      // Clean up input files
      for (const tempPath of tempInputPaths) {
        try {
          await unlink(tempPath);
        } catch (e) {
          // Ignore cleanup errors
        }
      }

      return NextResponse.json({
        success: true,
        jobId,
        resultFile: {
          filename: outputFilename,
          size: fileSize,
          sizeFormatted: formatBytes(fileSize),
          processingTimeMs: processingTime,
        },
      });
    } catch (error) {
      // Update job as failed
      const errorMessage =
        error instanceof Error ? error.message : "Unknown error";
      await db
        .update(processingJobs)
        .set({
          status: "FAILED",
          errorMessage,
          completedAt: new Date(),
        })
        .where(eq(processingJobs.id, jobId));

      return NextResponse.json(
        { error: errorMessage },
        { status: 500 }
      );
    }
  } catch (error) {
    console.error("Merge PDF error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
