# LOVE PDF

**Powerful PDF Tools. Simple by Design.**

A production-ready, full-stack PDF processing SaaS platform built with Next.js, React, TypeScript, PostgreSQL, and Drizzle ORM.

## Features

### Core PDF Tools (56 Tools)
- **Organize**: Merge, split, extract pages, rearrange, rotate, add page numbers
- **Optimize**: Compress, optimize, repair, flatten PDFs
- **Convert**: JPG/PNG/WebP to PDF, Word/Excel/PowerPoint to PDF
- **Convert From**: PDF to Word, Excel, images, text, HTML
- **Edit**: Add text, images, shapes, highlight, draw, watermark
- **Security**: Protect, unlock, encrypt, remove passwords
- **Sign**: Digital signatures, signature requests
- **OCR & AI**: Make PDFs searchable, AI analysis

### Advanced Features
- **AI PDF**: Ask questions about documents, summarize, extract information
- **User Authentication**: Secure registration, login, session management
- **Subscription System**: Free, Pro, and Business plans with Stripe integration
- **Cloud Storage**: Save processed PDFs to user accounts
- **API Platform**: REST API with API key authentication
- **Team Workspace**: Collaborate in teams with role-based access
- **File Sharing**: Secure sharing links with expiration and password protection
- **Audit Logs**: Track all user actions for compliance

## Technology Stack

### Frontend
- **Next.js 16** - React framework with App Router
- **React 19** - UI library
- **TypeScript** - Type-safe development
- **Tailwind CSS** - Utility-first styling
- **Lucide React** - Icon library

### Backend
- **Next.js API Routes** - Serverless functions
- **PostgreSQL** - Relational database
- **Drizzle ORM** - Type-safe database layer
- **PDF.js** - PDF viewing and processing
- **pdf-lib** - PDF creation and manipulation

### Authentication & Security
- **JWT-based sessions** - Secure token authentication
- **Password hashing** - SHA256 with salt
- **CSRF protection** - Automatic with Next.js
- **Rate limiting** - Protection against abuse
- **Environment variables** - Secure secrets management

### Payment Processing
- **Stripe API** - Payment processing
- **Stripe Webhooks** - Subscription management

## Project Structure

```
love-pdf/
├── src/
│   ├── app/
│   │   ├── api/              # API routes
│   │   │   ├── auth/         # Authentication endpoints
│   │   │   ├── tools/        # PDF processing endpoints
│   │   │   └── files/        # File management
│   │   ├── dashboard/        # User dashboard
│   │   ├── merge-pdf/        # Tool pages
│   │   ├── pricing/          # Pricing page
│   │   ├── login/            # Authentication pages
│   │   ├── signup/           
│   │   ├── help/             # Support pages
│   │   ├── privacy/          # Legal pages
│   │   ├── terms/
│   │   ├── layout.tsx        # Root layout
│   │   ├── page.tsx          # Homepage
│   │   └── globals.css       # Global styles
│   ├── db/
│   │   ├── schema.ts         # Database schema
│   │   └── index.ts          # Database connection
│   └── lib/
│       ├── auth.ts           # Authentication utilities
│       ├── constants.ts      # Application constants
│       ├── utils.ts          # Utility functions
│       └── pdf-processor.ts  # PDF processing functions
├── public/                   # Static assets
├── .env                      # Environment variables (git-ignored)
├── .env.example              # Environment template
├── docker-compose.yml        # Development Docker setup
├── Dockerfile                # Production Docker image
├── package.json              # Dependencies
├── tsconfig.json             # TypeScript configuration
└── next.config.ts            # Next.js configuration
```

## Getting Started

### Prerequisites
- Node.js 18+
- PostgreSQL 14+
- npm or yarn

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/love-pdf.git
cd love-pdf
```

2. **Install dependencies**
```bash
npm install
```

3. **Set up environment variables**
```bash
cp .env.example .env
# Edit .env with your configuration
```

4. **Set up the database**
```bash
npx drizzle-kit push
```

5. **Run development server**
```bash
npm run dev
```

The application will be available at `http://localhost:3000`

## Environment Variables

```env
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/lovepdf

# Authentication
AUTH_SECRET=your-secret-key-min-32-characters

# OAuth (Optional)
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret

# Payment Processing (Stripe)
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...

# AI Integration (Optional)
AI_API_KEY=your-ai-provider-key

# Email (Optional)
EMAIL_FROM=noreply@lovepdf.com
SENDGRID_API_KEY=SG.xxx

# File Storage (S3-compatible)
STORAGE_ENDPOINT=https://s3.amazonaws.com
STORAGE_ACCESS_KEY=your-access-key
STORAGE_SECRET_KEY=your-secret-key
STORAGE_BUCKET=lovepdf-files

# Redis (Optional, for background jobs)
REDIS_URL=redis://localhost:6379

# Node Environment
NODE_ENV=development
```

## API Documentation

### Authentication

#### Register
```bash
POST /api/auth/register
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "SecurePassword123"
}
```

#### Login
```bash
POST /api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "SecurePassword123"
}
```

#### Get Current User
```bash
GET /api/auth/me
```

### PDF Tools

#### Merge PDF
```bash
POST /api/tools/merge-pdf
Content-Type: multipart/form-data

Form data: files (multiple PDF files)
```

Response:
```json
{
  "success": true,
  "jobId": 123,
  "resultFile": {
    "id": 456,
    "filename": "merged-abc123.pdf",
    "size": 2048000,
    "sizeFormatted": "1.95 MB",
    "processingTimeMs": 1234
  }
}
```

#### Download File
```bash
GET /api/files/{filename}/download
```

## Database Schema

### Core Tables
- **users** - User accounts
- **sessions** - Active sessions
- **subscriptions** - Subscription status
- **payments** - Payment history

### Files & Storage
- **files** - User files
- **share_links** - Secure sharing
- **processing_jobs** - PDF jobs

### AI & Features
- **ai_conversations** - AI chat history
- **ai_messages** - AI messages
- **apikeys** - API authentication

### Organization
- **teams** - Team workspaces
- **team_members** - Team membership
- **notifications** - User notifications

See `src/db/schema.ts` for complete schema.

## Development

### Run TypeScript Check
```bash
npm run typecheck
```

### Run Linter
```bash
npm run lint
```

### Build for Production
```bash
npm run build
npm run start
```

### Database Migrations
```bash
# Push schema changes
npx drizzle-kit push

# Generate migration files
npx drizzle-kit generate

# Apply migrations
npx drizzle-kit migrate
```

## Deployment

### Docker Deployment

```bash
# Build image
docker build -t love-pdf:latest .

# Run container
docker run -p 3000:3000 \
  -e DATABASE_URL=postgresql://... \
  -e AUTH_SECRET=... \
  love-pdf:latest
```

### Docker Compose (Development)
```bash
docker-compose up
```

### Production Platforms

#### Vercel
```bash
vercel deploy
```

#### Railway
```bash
railway up
```

#### AWS
See `DEPLOYMENT.md` for AWS-specific instructions.

## Security Considerations

1. **Secrets Management**
   - Never commit `.env` files
   - Use environment variable managers in production
   - Rotate API keys regularly

2. **File Security**
   - All files are encrypted in transit
   - Temporary files are auto-deleted after 24 hours
   - Signed URLs prevent unauthorized access

3. **Authentication**
   - Passwords hashed with SHA256
   - JWT tokens with 7-day expiration
   - Rate limiting on auth endpoints

4. **Data Privacy**
   - GDPR-compliant data handling
   - User consent for AI processing
   - No third-party data sharing

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is proprietary software. All rights reserved.

## Support

- **Email**: support@lovepdf.com
- **Website**: https://lovepdf.com
- **Documentation**: https://docs.lovepdf.com
- **Status Page**: https://status.lovepdf.com

## Roadmap

- [ ] Mobile applications (iOS/Android)
- [ ] Advanced OCR with multiple languages
- [ ] Batch processing for large files
- [ ] PDF form filling automation
- [ ] Advanced reporting and analytics
- [ ] Custom branding for enterprise users
- [ ] Webhook support for API users
- [ ] Advanced collaboration features

## Acknowledgments

Built with modern web technologies and best practices in mind.

---

**Made with ❤️ by the LOVE PDF team**
