# LOVE PDF - API Documentation

## Base URL

```
https://api.lovepdf.com/v1
```

## Authentication

All API requests require authentication using API keys.

### Obtaining an API Key

1. Log in to your account
2. Go to Settings → API Keys
3. Click "Create API Key"
4. Copy the key (shown only once)
5. Store securely

### Using Your API Key

Include the API key in the `Authorization` header:

```bash
Authorization: Bearer your_api_key_here
```

### Example

```bash
curl -H "Authorization: Bearer sk_live_abc123" \
  https://api.lovepdf.com/v1/tools/merge-pdf
```

## Rate Limiting

- **Free Plan**: 100 requests/hour, 1000/day
- **Pro Plan**: 1000 requests/hour, 10000/day
- **Business Plan**: 10000 requests/hour, unlimited/day

Rate limit info in response headers:
- `X-RateLimit-Limit`: Total allowed requests
- `X-RateLimit-Remaining`: Requests left
- `X-RateLimit-Reset`: Unix timestamp when limit resets

## Error Handling

All errors return JSON with:

```json
{
  "error": "error_code",
  "message": "Human-readable error message",
  "details": {}
}
```

### HTTP Status Codes

- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `409` - Conflict
- `429` - Too Many Requests
- `500` - Server Error
- `503` - Service Unavailable

## API Endpoints

### Authentication

#### Register

```
POST /auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePassword123",
  "name": "User Name"
}
```

Response:
```json
{
  "success": true,
  "user": {
    "id": 1,
    "email": "user@example.com",
    "name": "User Name"
  }
}
```

#### Login

```
POST /auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePassword123"
}
```

Response:
```json
{
  "success": true,
  "user": {
    "id": 1,
    "email": "user@example.com",
    "name": "User Name",
    "role": "PRO"
  },
  "token": "session_token"
}
```

#### Get Current User

```
GET /auth/me
Authorization: Bearer your_api_key
```

Response:
```json
{
  "user": {
    "id": 1,
    "email": "user@example.com",
    "name": "User Name",
    "role": "PRO",
    "avatar": "https://..."
  }
}
```

### PDF Tools

#### Merge PDFs

```
POST /tools/merge-pdf
Authorization: Bearer your_api_key
Content-Type: multipart/form-data

files: [pdf1.pdf, pdf2.pdf, pdf3.pdf]
```

Response:
```json
{
  "success": true,
  "jobId": 12345,
  "resultFile": {
    "filename": "merged-abc123.pdf",
    "size": 2048000,
    "sizeFormatted": "1.95 MB",
    "processingTimeMs": 1234
  }
}
```

#### Compress PDF

```
POST /tools/compress-pdf
Authorization: Bearer your_api_key
Content-Type: multipart/form-data

file: input.pdf
quality: "recommended" (or "maximum", "high_quality")
```

Response:
```json
{
  "success": true,
  "jobId": 12346,
  "resultFile": {
    "filename": "compressed-def456.pdf",
    "originalSize": 5242880,
    "originalSizeFormatted": "5 MB",
    "compressedSize": 1572864,
    "compressedSizeFormatted": "1.5 MB",
    "savedPercent": 70,
    "processingTimeMs": 2345
  }
}
```

#### Split PDF

```
POST /tools/split-pdf
Authorization: Bearer your_api_key
Content-Type: multipart/form-data

file: input.pdf
pages: "1-5,8-12,15"
```

Response:
```json
{
  "success": true,
  "jobId": 12347,
  "resultFiles": [
    {
      "filename": "split-1-abc123.pdf",
      "pages": "1-5",
      "size": 1024000
    },
    {
      "filename": "split-2-def456.pdf",
      "pages": "8-12",
      "size": 1024000
    },
    {
      "filename": "split-3-ghi789.pdf",
      "pages": "15",
      "size": 512000
    }
  ]
}
```

#### Add Watermark

```
POST /tools/watermark-pdf
Authorization: Bearer your_api_key
Content-Type: multipart/form-data

file: input.pdf
text: "CONFIDENTIAL"
opacity: 0.5
fontSize: 50
pages: "all" (or comma-separated page numbers)
```

Response:
```json
{
  "success": true,
  "jobId": 12348,
  "resultFile": {
    "filename": "watermarked-jkl012.pdf",
    "size": 2048000,
    "sizeFormatted": "1.95 MB"
  }
}
```

#### Convert PDF to Image

```
POST /tools/pdf-to-jpg
Authorization: Bearer your_api_key
Content-Type: multipart/form-data

file: input.pdf
pages: "all" (or comma-separated)
quality: "high" (or "medium", "low")
```

Response:
```json
{
  "success": true,
  "jobId": 12349,
  "resultFiles": [
    {
      "filename": "page-1.jpg",
      "page": 1,
      "size": 512000
    },
    {
      "filename": "page-2.jpg",
      "page": 2,
      "size": 524000
    }
  ]
}
```

#### Convert Image to PDF

```
POST /tools/jpg-to-pdf
Authorization: Bearer your_api_key
Content-Type: multipart/form-data

files: [image1.jpg, image2.jpg]
orientation: "auto" (or "portrait", "landscape")
```

Response:
```json
{
  "success": true,
  "jobId": 12350,
  "resultFile": {
    "filename": "converted-mno345.pdf",
    "size": 2048000,
    "pageCount": 2
  }
}
```

### Files

#### List Files

```
GET /files?limit=20&offset=0
Authorization: Bearer your_api_key
```

Response:
```json
{
  "files": [
    {
      "id": 1,
      "filename": "document.pdf",
      "size": 2048000,
      "sizeFormatted": "1.95 MB",
      "createdAt": "2024-01-15T10:30:00Z",
      "isFavorite": false
    }
  ],
  "total": 45,
  "limit": 20,
  "offset": 0
}
```

#### Get File

```
GET /files/{fileId}
Authorization: Bearer your_api_key
```

Response:
```json
{
  "file": {
    "id": 1,
    "filename": "document.pdf",
    "size": 2048000,
    "sizeFormatted": "1.95 MB",
    "createdAt": "2024-01-15T10:30:00Z",
    "updatedAt": "2024-01-15T10:30:00Z",
    "isFavorite": false,
    "isPublic": false
  }
}
```

#### Download File

```
GET /files/{fileId}/download
Authorization: Bearer your_api_key
```

Returns binary PDF file.

#### Delete File

```
DELETE /files/{fileId}
Authorization: Bearer your_api_key
```

Response:
```json
{
  "success": true,
  "message": "File deleted"
}
```

### Jobs

#### Get Job Status

```
GET /jobs/{jobId}
Authorization: Bearer your_api_key
```

Response:
```json
{
  "job": {
    "id": 12345,
    "status": "COMPLETED",
    "toolType": "MERGE",
    "createdAt": "2024-01-15T10:30:00Z",
    "completedAt": "2024-01-15T10:31:30Z",
    "processingTimeMs": 90000,
    "resultFileId": 5
  }
}
```

#### Cancel Job

```
DELETE /jobs/{jobId}
Authorization: Bearer your_api_key
```

Response:
```json
{
  "success": true,
  "message": "Job cancelled"
}
```

### Subscriptions

#### Get Subscription

```
GET /subscriptions/current
Authorization: Bearer your_api_key
```

Response:
```json
{
  "subscription": {
    "id": 1,
    "plan": "PRO",
    "status": "ACTIVE",
    "currentPeriodStart": "2024-01-01T00:00:00Z",
    "currentPeriodEnd": "2024-02-01T00:00:00Z",
    "renewalDate": "2024-02-01T00:00:00Z",
    "autoRenew": true
  }
}
```

#### Update Subscription

```
POST /subscriptions/update
Authorization: Bearer your_api_key
Content-Type: application/json

{
  "plan": "BUSINESS",
  "billingCycle": "yearly"
}
```

Response:
```json
{
  "success": true,
  "subscription": {
    "plan": "BUSINESS",
    "billingCycle": "yearly"
  }
}
```

#### Cancel Subscription

```
POST /subscriptions/cancel
Authorization: Bearer your_api_key
```

Response:
```json
{
  "success": true,
  "message": "Subscription cancelled",
  "effectiveDate": "2024-02-01T00:00:00Z"
}
```

### Usage

#### Get Usage Statistics

```
GET /usage?period=month
Authorization: Bearer your_api_key
```

Response:
```json
{
  "usage": {
    "period": "month",
    "tasksUsed": 42,
    "tasksLimit": 500,
    "storageUsed": 2048000000,
    "storageLimit": 10737418240,
    "apiRequestsUsed": 1234,
    "apiRequestsLimit": 10000,
    "aiRequestsUsed": 45,
    "aiRequestsLimit": 1000
  }
}
```

## Webhooks

### Webhook Events

Subscribe to events at https://lovepdf.com/account/webhooks

#### Available Events

- `job.completed` - PDF processing completed
- `job.failed` - PDF processing failed
- `subscription.activated` - Subscription started
- `subscription.cancelled` - Subscription cancelled
- `subscription.renewal_failed` - Payment failed

#### Webhook Payload

```json
{
  "event": "job.completed",
  "timestamp": "2024-01-15T10:31:30Z",
  "data": {
    "jobId": 12345,
    "status": "COMPLETED",
    "resultFileId": 5
  }
}
```

#### Verify Webhook Signature

```typescript
import crypto from 'crypto';

function verifyWebhook(payload: string, signature: string) {
  const hash = crypto
    .createHmac('sha256', process.env.WEBHOOK_SECRET)
    .update(payload)
    .digest('hex');
  
  return hash === signature;
}
```

## Code Examples

### Python

```python
import requests

api_key = "your_api_key"
headers = {
    "Authorization": f"Bearer {api_key}",
    "Content-Type": "application/json"
}

# Merge PDFs
with open("pdf1.pdf", "rb") as f1, open("pdf2.pdf", "rb") as f2:
    files = {"files": [f1, f2]}
    response = requests.post(
        "https://api.lovepdf.com/v1/tools/merge-pdf",
        files=files,
        headers=headers
    )
    print(response.json())
```

### JavaScript/Node.js

```javascript
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');

const api = axios.create({
  baseURL: 'https://api.lovepdf.com/v1',
  headers: {
    'Authorization': `Bearer ${process.env.API_KEY}`
  }
});

async function mergePDFs() {
  const form = new FormData();
  form.append('files', fs.createReadStream('pdf1.pdf'));
  form.append('files', fs.createReadStream('pdf2.pdf'));

  try {
    const response = await api.post('/tools/merge-pdf', form, {
      headers: form.getHeaders()
    });
    console.log(response.data);
  } catch (error) {
    console.error(error.response.data);
  }
}

mergePDFs();
```

### cURL

```bash
# Merge PDFs
curl -X POST https://api.lovepdf.com/v1/tools/merge-pdf \
  -H "Authorization: Bearer your_api_key" \
  -F "files=@pdf1.pdf" \
  -F "files=@pdf2.pdf"

# Compress PDF
curl -X POST https://api.lovepdf.com/v1/tools/compress-pdf \
  -H "Authorization: Bearer your_api_key" \
  -F "file=@input.pdf" \
  -F "quality=recommended"

# Get job status
curl -X GET https://api.lovepdf.com/v1/jobs/12345 \
  -H "Authorization: Bearer your_api_key"
```

## Best Practices

1. **Store API Keys Securely**: Never commit keys to version control
2. **Use Environment Variables**: Keep secrets in `.env` files
3. **Handle Rate Limits**: Implement exponential backoff
4. **Validate Input**: Check file types and sizes before sending
5. **Monitor Usage**: Track your API requests and usage
6. **Error Handling**: Implement proper error handling and retries
7. **Webhooks**: Use webhooks instead of polling for job status
8. **Timeouts**: Set appropriate request timeouts
9. **Compression**: Compress files before sending if possible
10. **Logging**: Log all requests and responses for debugging

## Changelog

### v1.0.0 (January 2024)
- Initial API release
- Merge, compress, split, watermark tools
- File management endpoints
- Subscription management
- Usage tracking

## Support

- **Documentation**: https://docs.lovepdf.com
- **Issues**: support@lovepdf.com
- **Status**: https://status.lovepdf.com

---

**Last Updated**: January 2024
