# LOVE PDF - Architecture Overview

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        Client Layer                          │
│  (Web Browser, Mobile, CLI, Third-party Applications)        │
└────────────────┬────────────────────────────────┬────────────┘
                 │                                │
                 │ HTTP/HTTPS                     │
                 │ WebSocket (Optional)           │
                 │                                │
┌────────────────▼────────────────────────────────▼────────────┐
│                     API Gateway / CDN                         │
│              (Vercel, CloudFront, Nginx)                      │
└────────────────┬────────────────────────────────┬────────────┘
                 │                                │
┌────────────────▼────────────────────────────────▼────────────┐
│                    Next.js Application                        │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              Page Layer (React)                      │   │
│  │  - Homepage                                          │   │
│  │  - Tool Pages                                        │   │
│  │  - Dashboard                                         │   │
│  │  - Auth Pages                                        │   │
│  └──────────────────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              API Routes                              │   │
│  │  - /api/auth/*          (Authentication)            │   │
│  │  - /api/tools/*         (PDF Processing)            │   │
│  │  - /api/files/*         (File Management)           │   │
│  │  - /api/subscriptions/* (Billing)                   │   │
│  └──────────────────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              Service Layer                           │   │
│  │  - Authentication                                   │   │
│  │  - Authorization                                    │   │
│  │  - File Handling                                    │   │
│  │  - PDF Processing Orchestration                     │   │
│  │  - Error Handling                                   │   │
│  └──────────────────────────────────────────────────────┘   │
└────────────────┬────────────────────────────────┬────────────┘
                 │                                │
     ┌───────────┴─────────────┬─────────────┬───┴───────────┐
     │                         │             │               │
┌────▼────┐         ┌──────────▼──┐  ┌──────▼────┐  ┌───────▼───┐
│PostgreSQL│         │   Redis    │  │   S3      │  │  External │
│Database  │         │   Cache    │  │  Storage  │  │  Services │
│          │         │            │  │           │  │           │
│- Users   │         │- Sessions  │  │- PDFs     │  │- Stripe   │
│- Files   │         │- Queue     │  │- Results  │  │- OpenAI   │
│- Jobs    │         │- Cache     │  │- Avatars  │  │- Email    │
│- Auth    │         │            │  │           │  │           │
└──────────┘         └────────────┘  └───────────┘  └───────────┘
```

## Layers & Components

### 1. Presentation Layer

**Technologies**: React 19, Tailwind CSS, Lucide Icons

**Components**:
- Pages (Homepage, Dashboard, Tools, Pricing, Auth)
- UI Components (Button, Input, Modal, Card)
- Forms (Login, Registration, Tool Configuration)
- Charts & Analytics Displays

**Responsibilities**:
- Render user interface
- Handle user interactions
- Client-side validation
- State management

### 2. API Layer

**Framework**: Next.js API Routes

**Endpoints**:

#### Authentication Routes
```
POST   /api/auth/register      - User registration
POST   /api/auth/login         - User login
POST   /api/auth/logout        - User logout
GET    /api/auth/me            - Get current user
```

#### PDF Tool Routes
```
POST   /api/tools/merge-pdf    - Merge PDFs
POST   /api/tools/compress-pdf - Compress PDF
POST   /api/tools/split-pdf    - Split PDF
POST   /api/tools/watermark-pdf- Add watermark
POST   /api/tools/ocr-pdf      - OCR processing
```

#### File Management Routes
```
GET    /api/files              - List files
GET    /api/files/{id}         - Get file details
GET    /api/files/{id}/download- Download file
DELETE /api/files/{id}         - Delete file
```

#### Subscription Routes
```
GET    /api/subscriptions/current  - Get subscription
POST   /api/subscriptions/update   - Update plan
POST   /api/subscriptions/cancel   - Cancel subscription
GET    /api/usage                  - Get usage stats
```

### 3. Service Layer

**Responsibilities**:
- Business logic
- Data validation
- Authentication/Authorization
- PDF processing orchestration
- External API integrations

**Key Services**:
- `AuthService` - User authentication and session management
- `PDFService` - PDF processing operations
- `FileService` - File storage and retrieval
- `SubscriptionService` - Subscription management
- `PaymentService` - Stripe integration
- `NotificationService` - Email and in-app notifications

### 4. Data Access Layer (Drizzle ORM)

**ORM**: Drizzle ORM with PostgreSQL

**Key Tables**:

```
users
├── id (PK)
├── email (UNIQUE)
├── password_hash
├── name
├── role (FREE, PRO, BUSINESS)
├── avatar
├── created_at
└── updated_at

files
├── id (PK)
├── user_id (FK)
├── filename
├── mime_type
├── size
├── storage_path
├── storage_key
├── expires_at
└── created_at

processing_jobs
├── id (PK)
├── user_id (FK)
├── file_id (FK)
├── tool_type (MERGE, COMPRESS, etc)
├── status (PENDING, PROCESSING, COMPLETED, FAILED)
├── parameters (JSONB)
├── result_file_id (FK)
├── processing_time_ms
└── completed_at

subscriptions
├── id (PK)
├── user_id (FK)
├── plan (FREE, PRO, BUSINESS)
├── status (ACTIVE, CANCELLED)
├── stripe_customer_id
├── stripe_subscription_id
├── current_period_end
└── cancelled_at
```

### 5. External Services

**Stripe**:
- Payment processing
- Subscription management
- Webhook handling

**PDF Processing Libraries**:
- `pdf-lib` - PDF creation and manipulation
- `PDF.js` - PDF viewing and extraction
- `pdfjs-dist` - Browser-based PDF rendering

**Email Service**:
- SendGrid / SMTP for transactional emails

**Storage**:
- S3-compatible object storage for files

**Cache/Queue**:
- Redis for session caching and job queues

## Data Flow

### PDF Processing Flow

```
1. User Upload
   ├─ Browser validates file type/size
   ├─ File sent to /api/tools/{tool-type}
   └─ Server validates and creates job record

2. Processing Queue
   ├─ Job added to processing_jobs table
   ├─ Status set to PROCESSING
   └─ Request returns jobId to client

3. File Processing
   ├─ Server reads file from temp storage
   ├─ Apply PDF processing operation
   ├─ Write result to temp directory
   └─ Update job status to COMPLETED

4. Result Storage
   ├─ File metadata saved to database
   ├─ Generate download URL
   ├─ Optional: Copy to cloud storage (S3)
   └─ Set expiration time

5. Result Delivery
   ├─ Client polls job status
   ├─ GET /api/jobs/{jobId}
   ├─ When completed, show download button
   └─ User downloads result file
```

### Authentication Flow

```
1. User Registration
   ├─ POST /api/auth/register
   ├─ Validate email & password
   ├─ Hash password (SHA256)
   ├─ Create user record
   └─ Generate JWT token

2. User Login
   ├─ POST /api/auth/login
   ├─ Verify email exists
   ├─ Compare password hash
   ├─ Create session record
   ├─ Generate JWT token
   └─ Set HTTP-only cookie

3. Authenticated Requests
   ├─ Client sends request with cookie
   ├─ Middleware verifies JWT signature
   ├─ Extract user ID from token
   ├─ Validate session in database
   └─ Proceed with request

4. Session Expiration
   ├─ 7-day default expiration
   ├─ Auto-refresh on client-side
   ├─ Logout clears session
   └─ Expired sessions cleaned by cron
```

### Subscription/Payment Flow

```
1. Subscribe to Plan
   ├─ User selects plan
   ├─ Creates Stripe session
   ├─ User redirected to Stripe checkout
   └─ Returns to success page

2. Payment Processing
   ├─ Stripe processes payment
   ├─ Sends webhook to our server
   ├─ Verify webhook signature
   └─ Update subscription status

3. Ongoing Management
   ├─ Auto-renew at period end
   ├─ Send renewal reminders
   ├─ Handle payment failures
   ├─ Allow plan changes
   └─ Enable cancellation
```

## Security Architecture

### Authentication Security
```
┌─────────────────┐
│ User Password   │
└────────┬────────┘
         │
         ├─ SHA256 Hash with salt
         │
┌────────▼────────┐
│ Password Hash   │
└────────┬────────┘
         │
         └─ Stored in database
```

### Session Security
```
┌──────────────────┐
│ User ID + Email  │
└────────┬─────────┘
         │
         ├─ HMAC-SHA256 sign
         │  (AUTH_SECRET)
         │
┌────────▼─────────┐
│   JWT Token      │
└────────┬─────────┘
         │
         ├─ Set in HTTP-only cookie
         │  (secure, sameSite=lax)
         │
         └─ Expires in 7 days
```

### File Security
```
User Upload
    ├─ Validate MIME type
    ├─ Check file size
    ├─ Scan for malware (optional)
    │
    ├─ Save to temporary directory
    │  (with random filename)
    │
    ├─ Auto-delete after 24 hours
    │
    └─ Serve only to authenticated
       users via signed URLs
```

### API Security
```
┌────────────────────┐
│   API Request      │
└────────┬───────────┘
         │
         ├─ Verify API Key
         ├─ Check rate limits
         ├─ Validate input
         ├─ Verify signatures
         │  (for webhooks)
         │
┌────────▼───────────┐
│  Process Request   │
└────────┬───────────┘
         │
         ├─ Query database
         ├─ Enforce permissions
         ├─ Log actions
         │
┌────────▼───────────┐
│  Return Response   │
└────────────────────┘
```

## Scalability Considerations

### Horizontal Scaling
```
Load Balancer (Nginx/HAProxy)
        │
        ├─ App Server 1
        ├─ App Server 2
        └─ App Server N
        
    ↓
    
Shared Database (PostgreSQL)
Shared Cache (Redis)
Shared Storage (S3)
```

### Database Optimization
- Connection pooling (PgBouncer)
- Query optimization with indexes
- Prepared statements
- Read replicas for analytics
- Sharding by user_id for massive scale

### Caching Strategy
- Session caching in Redis
- Database query caching
- User permission caching
- Invalidation on updates

### File Processing
- Async processing with job queue
- Background workers
- Retry logic for failures
- Progress tracking via WebSockets

## Deployment Architecture

### Development
```
Local Machine
├─ Next.js Dev Server (localhost:3000)
├─ PostgreSQL (Docker)
├─ Redis (Docker)
└─ File system storage
```

### Production (Recommended)
```
Vercel / AWS / Railway
├─ Multiple Next.js instances
├─ PostgreSQL database
├─ Redis cluster
├─ S3 object storage
├─ CDN (CloudFront / Vercel Edge)
└─ Email service (SendGrid)
```

### Infrastructure
```
┌─────────────────────────────┐
│        DNS/CDN              │
│    (Vercel Edge Network)    │
└────────────┬────────────────┘
             │
      ┌──────▼──────┐
      │    WAF      │
      └──────┬──────┘
             │
      ┌──────▼───────────┐
      │   Load Balancer  │
      └──────┬───────────┘
             │
    ┌────────┼────────┐
    │        │        │
┌───▼──┐ ┌──▼───┐ ┌──▼───┐
│App-1 │ │App-2 │ │App-N │
└───┬──┘ └──┬───┘ └──┬───┘
    │       │       │
    └───────┬───────┘
            │
    ┌───────┴────────┐
    │                │
┌───▼─────┐    ┌────▼────┐
│PostgreSQL│   │  Redis   │
└──────────┘    └──────────┘
```

## Technology Decision Matrix

| Feature | Technology | Why |
|---------|-----------|-----|
| Frontend | React | Fast, component-based, large ecosystem |
| Framework | Next.js | Full-stack, SSR, API routes, edge functions |
| Styling | Tailwind CSS | Utility-first, fast development |
| Database | PostgreSQL | Reliable, ACID compliant, rich features |
| ORM | Drizzle | Type-safe, modern, minimal overhead |
| PDF Processing | pdf-lib | Pure JS, no native dependencies |
| Auth | JWT + Sessions | Stateless, scalable, secure |
| Payment | Stripe | Reliable, PCI compliant, webhooks |
| Storage | S3 | Scalable, cost-effective, CDN-friendly |
| Cache | Redis | Fast, in-memory, session storage |
| Deployment | Vercel | Optimized for Next.js, edge functions |

## Performance Metrics

**Target Performance**:
- Page load: <2 seconds
- API response: <500ms
- PDF processing: 2-30 seconds (depends on operation)
- Database query: <100ms (p95)

**Monitoring**:
- Application Performance Monitoring (APM)
- Error tracking (Sentry)
- Uptime monitoring
- Log aggregation (ELK stack)
- Real User Monitoring (RUM)

---

**Last Updated**: January 2024
