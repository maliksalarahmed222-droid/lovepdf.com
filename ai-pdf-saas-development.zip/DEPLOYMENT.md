# LOVE PDF - Deployment Guide

## Pre-Deployment Checklist

- [ ] All tests passing
- [ ] No TypeScript errors
- [ ] Environment variables configured
- [ ] Database migrations applied
- [ ] Secrets stored securely
- [ ] API keys configured
- [ ] CORS settings verified
- [ ] Rate limiting enabled
- [ ] Error tracking configured
- [ ] Backups configured

## Deployment Platforms

### 1. Vercel (Recommended for Next.js)

#### Setup

```bash
# Install Vercel CLI
npm i -g vercel

# Login to Vercel
vercel login

# Deploy
vercel deploy --prod
```

#### Environment Variables

1. Go to Vercel Dashboard
2. Project Settings → Environment Variables
3. Add all variables from `.env`

#### Database

1. Use Vercel Postgres or external PostgreSQL
2. Set `DATABASE_URL` in environment variables
3. Run migrations:

```bash
vercel env pull
npx drizzle-kit push
```

#### Performance

- Automatic image optimization
- Edge functions for API routes
- Built-in caching and CDN
- Automatic scaling

### 2. Railway

#### Setup

```bash
# Install Railway CLI
npm i -g @railway/cli

# Login
railway login

# Link project
railway link

# Deploy
railway up
```

#### Add Services

```bash
# PostgreSQL
railway add --postgres

# Redis (optional)
railway add --redis
```

#### Environment Variables

```bash
railway env add DATABASE_URL postgresql://...
railway env add AUTH_SECRET ...
```

#### Start Services

```bash
railway up
```

### 3. Render

#### Setup

1. Connect GitHub repository
2. Create new Web Service
3. Select Node.js environment
4. Set build command: `npm run build`
5. Set start command: `npm start`

#### Database

1. Create PostgreSQL database
2. Add `DATABASE_URL` to environment variables
3. Deploy

### 4. AWS (Elastic Beanstalk)

#### Preparation

```bash
# Install AWS CLI
pip install awscli

# Configure credentials
aws configure
```

#### Deploy

```bash
# Install EB CLI
pip install awsebcli

# Initialize
eb init

# Create environment
eb create love-pdf-env

# Deploy
eb deploy

# Open application
eb open
```

#### Database (RDS)

1. Create RDS PostgreSQL instance
2. Add security group rules
3. Set `DATABASE_URL` in environment

#### Configuration

```yaml
# .ebextensions/01_environment.yaml
option_settings:
  aws:elasticbeanstalk:container:nodejs:
    NodeCommand: "npm start"
  aws:elasticbeanstalk:application:environment:
    NODE_ENV: production
    DATABASE_URL: $RDS_URL
    AUTH_SECRET: $AUTH_SECRET
```

### 5. DigitalOcean App Platform

#### Setup

1. Connect GitHub repository
2. Create new App
3. Select Node.js
4. Configure build and run commands

#### Build Command

```
npm install && npm run build
```

#### Run Command

```
npm start
```

#### Add Database

1. Create managed PostgreSQL database
2. Copy connection string
3. Add to environment variables

### 6. Docker & Kubernetes

#### Build Docker Image

```bash
# Build
docker build -t love-pdf:latest .

# Test locally
docker run -p 3000:3000 \
  -e DATABASE_URL=postgresql://... \
  -e AUTH_SECRET=... \
  love-pdf:latest
```

#### Push to Registry

```bash
# Docker Hub
docker tag love-pdf:latest yourname/love-pdf:latest
docker push yourname/love-pdf:latest

# AWS ECR
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin your-ecr-url
docker tag love-pdf:latest your-ecr-url/love-pdf:latest
docker push your-ecr-url/love-pdf:latest
```

#### Kubernetes Deployment

```yaml
# kubernetes/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: love-pdf
spec:
  replicas: 3
  selector:
    matchLabels:
      app: love-pdf
  template:
    metadata:
      labels:
        app: love-pdf
    spec:
      containers:
      - name: love-pdf
        image: your-registry/love-pdf:latest
        ports:
        - containerPort: 3000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: love-pdf-secrets
              key: database-url
        - name: AUTH_SECRET
          valueFrom:
            secretKeyRef:
              name: love-pdf-secrets
              key: auth-secret
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"
```

## Production Environment Variables

```env
# Core
NODE_ENV=production
AUTH_SECRET=your-very-secure-secret-key-32-chars-minimum

# Database
DATABASE_URL=postgresql://user:password@host:5432/lovepdf

# Redis (for caching and jobs)
REDIS_URL=redis://host:6379

# API Keys
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
OPENAI_API_KEY=sk-...

# Email
SENDGRID_API_KEY=SG....
EMAIL_FROM=noreply@lovepdf.com

# Storage
STORAGE_ENDPOINT=https://s3.amazonaws.com
STORAGE_ACCESS_KEY=...
STORAGE_SECRET_KEY=...
STORAGE_BUCKET=lovepdf-prod

# Monitoring
SENTRY_DSN=https://...
VERCEL_ANALYTICS_ID=...
```

## Database Migration (Production)

```bash
# Backup first
pg_dump postgresql://user:password@host:5432/lovepdf > backup.sql

# Run migrations
DATABASE_URL=postgresql://... npx drizzle-kit migrate

# Verify
DATABASE_URL=postgresql://... npx drizzle-kit introspect
```

## SSL/HTTPS Setup

### Let's Encrypt (Free)

```bash
# Using Certbot
sudo certbot certonly --standalone -d lovepdf.com

# Auto-renewal
sudo systemctl enable certbot.timer
```

### Nginx Configuration

```nginx
server {
    listen 443 ssl http2;
    server_name lovepdf.com;

    ssl_certificate /etc/letsencrypt/live/lovepdf.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/lovepdf.com/privkey.pem;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}

server {
    listen 80;
    server_name lovepdf.com;
    return 301 https://$server_name$request_uri;
}
```

## Monitoring & Logging

### Application Monitoring

```bash
npm install pm2 -g

# Start with PM2
pm2 start npm --name "love-pdf" -- start

# Monitor
pm2 monit

# Logs
pm2 logs love-pdf
```

### Error Tracking

```bash
npm install @sentry/nextjs
```

Add to `next.config.ts`:
```ts
import * as Sentry from "@sentry/nextjs";

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV,
});
```

### Database Monitoring

```bash
# Connection monitoring
SELECT datname, usename, count(*) FROM pg_stat_activity GROUP BY datname, usename;

# Slow query log
ALTER SYSTEM SET log_min_duration_statement = 1000;
SELECT pg_reload_conf();
```

## Load Balancing

### Nginx Load Balancer

```nginx
upstream love_pdf {
    server app1.example.com:3000;
    server app2.example.com:3000;
    server app3.example.com:3000;
}

server {
    listen 80;
    server_name lovepdf.com;

    location / {
        proxy_pass http://love_pdf;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## Backup Strategy

### Automated Database Backups

```bash
# PostgreSQL backup script
#!/bin/bash
BACKUP_DIR="/backups/lovepdf"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

pg_dump postgresql://user:password@host:5432/lovepdf | \
  gzip > $BACKUP_DIR/lovepdf_$DATE.sql.gz

# Keep only last 7 days
find $BACKUP_DIR -name "*.sql.gz" -mtime +7 -delete
```

### S3 Backups

```bash
# Backup to S3
aws s3 cp /backups/lovepdf/ s3://lovepdf-backups/ --recursive --sse AES256

# Schedule with cron
0 2 * * * /scripts/backup-to-s3.sh
```

## Scaling

### Horizontal Scaling (Multiple Servers)

1. Deploy to multiple instances
2. Use load balancer (Nginx, HAProxy)
3. Share database and Redis
4. Use object storage (S3) for files

### Vertical Scaling (Larger Servers)

```bash
# Increase server resources
- RAM: 8GB → 16GB+
- CPU: 4 cores → 8 cores+
- Storage: 100GB → 1TB+
```

## Rollback Procedures

```bash
# Vercel rollback
vercel deploy --prod --skip-build

# Docker rollback
docker run -p 3000:3000 your-registry/love-pdf:previous-tag

# Database rollback
psql < backup.sql
```

## Post-Deployment

1. **Verify**: Test all features
2. **Monitor**: Check logs and metrics
3. **Alert**: Set up monitoring alerts
4. **Backup**: Ensure backups are working
5. **DNS**: Update DNS records if needed
6. **SSL**: Verify HTTPS is working
7. **Performance**: Run performance tests
8. **Security**: Run security scan

## Troubleshooting

### Application Won't Start

```bash
# Check logs
pm2 logs love-pdf

# Check environment variables
env | grep DATABASE

# Test database connection
psql $DATABASE_URL -c "SELECT 1"
```

### Database Connection Issues

```bash
# Check firewall rules
sudo ufw status

# Test connection
nc -zv db.example.com 5432

# Check credentials
echo $DATABASE_URL
```

### High Memory Usage

```bash
# Check memory
free -h

# Enable Node.js heap snapshot
node --max-old-space-size=4096 ...
```

## Maintenance Windows

Schedule downtime for:
- Database maintenance (1-2 hours monthly)
- Certificate renewal (automated)
- Dependency updates (weekly)
- Security patches (as needed)

Communicate maintenance windows:
- Email users 48 hours before
- Update status page
- Schedule during low-traffic hours

## Support & Escalation

- **Issues**: Contact platform support
- **Database**: Contact database provider
- **Security**: security@lovepdf.com
- **Emergency**: Page on-call team

---

**Last Updated**: January 2024
